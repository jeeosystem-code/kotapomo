package com.examcountdown.wallpaper

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.time.LocalDate
import java.time.LocalDateTime

object Notifier {
    private const val CHANNEL = "countdown"
    private val milestones = setOf(100L, 50L, 30L, 14L, 7L, 3L, 2L, 1L, 0L)

    private fun ensureChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Countdown reminders",
                NotificationManager.IMPORTANCE_DEFAULT))
        }
    }

    private fun allowed(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) return false
        return NotificationManagerCompat.from(ctx).areNotificationsEnabled()
    }

    @SuppressLint("MissingPermission")
    fun post(ctx: Context, id: Int, title: String, text: String) {
        if (!allowed(ctx)) return
        ensureChannel(ctx)
        val open = Intent(ctx, MainActivity::class.java)
        val pi = PendingIntent.getActivity(ctx, 0, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        try { NotificationManagerCompat.from(ctx).notify(id, n) } catch (e: SecurityException) { }
    }

    /** Called by the background job. Sends a milestone or daily message once per day. */
    fun check(ctx: Context) {
        val s = Prefs.load(ctx)
        if (s.notify == 0) return
        val today = LocalDate.now().toEpochDay()
        val e = Updater.effective(s, today)
        if (e.examDay < 0) return
        if (LocalDateTime.now().hour < s.notifyHour) return
        val days = e.examDay - today
        if (days < 0) return
        val should = s.notify == 2 || days in milestones
        if (!should) return
        val key = "$today|${e.examDay}"
        val sp = ctx.getSharedPreferences("notify", Context.MODE_PRIVATE)
        if (sp.getString("last", "") == key) return
        sp.edit().putString("last", key).apply()
        val title = when (days) {
            0L -> "Exam day: " + e.name + ". You’ve got this!"
            1L -> "1 day to go: " + e.name
            else -> "$days days to go: " + e.name
        }
        post(ctx, 1, title, Updater.quoteFor(s.copy(quote = true), today) ?: "")
    }
}

object Study {
    private fun sp(c: Context) = c.getSharedPreferences("study", Context.MODE_PRIVATE)

    fun minutes(c: Context, day: Long): Int = sp(c).getInt("d$day", 0)

    fun add(c: Context, day: Long, m: Int) {
        sp(c).edit().putInt("d$day", maxOf(0, minutes(c, day) + m)).apply()
    }

    fun resetDay(c: Context, day: Long) { sp(c).edit().remove("d$day").apply() }

    fun streak(c: Context, goalMin: Int, today: Long): Int {
        if (goalMin <= 0) return 0
        var d = today
        if (minutes(c, d) < goalMin) d = today - 1
        var n = 0
        while (n < 3650 && minutes(c, d) >= goalMin) { n++; d-- }
        return n
    }

    // ---- focus timer (works even if the app is closed)
    @Synchronized
    fun start(c: Context, minutes: Int, focus: Boolean) {
        sp(c).edit().putLong("end", System.currentTimeMillis() + minutes * 60_000L)
            .putInt("pm", minutes).putBoolean("pf", focus).apply()
        androidx.work.WorkManager.getInstance(c).enqueueUniqueWork("pomodoro",
            androidx.work.ExistingWorkPolicy.REPLACE,
            androidx.work.OneTimeWorkRequestBuilder<PomodoroWorker>()
                .setInitialDelay(minutes.toLong(), java.util.concurrent.TimeUnit.MINUTES).build())
    }

    @Synchronized
    fun cancel(c: Context) {
        sp(c).edit().putLong("end", 0L).apply()
        androidx.work.WorkManager.getInstance(c).cancelUniqueWork("pomodoro")
    }

    fun remainingMs(c: Context): Long {
        val end = sp(c).getLong("end", 0L)
        return if (end == 0L) -1L else end - System.currentTimeMillis()
    }

    fun isFocus(c: Context) = sp(c).getBoolean("pf", true)

    /** Logs the finished session once. Returns the finished kind and minutes, or null. */
    @Synchronized
    fun completeIfDue(c: Context): Pair<Boolean, Int>? {
        val p = sp(c)
        val end = p.getLong("end", 0L)
        if (end == 0L || System.currentTimeMillis() < end) return null
        val m = p.getInt("pm", 25)
        val focus = p.getBoolean("pf", true)
        p.edit().putLong("end", 0L).apply()
        if (focus) add(c, LocalDate.now().toEpochDay(), m)
        return Pair(focus, m)
    }
}

class PomodoroWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        val r = Study.completeIfDue(applicationContext)
        if (r != null) {
            if (r.first) Notifier.post(applicationContext, 2, "Focus session complete",
                "Great work! " + r.second + " minutes added to today.")
            else Notifier.post(applicationContext, 2, "Break over", "Ready for the next focus session?")
        }
        return Result.success()
    }
}
