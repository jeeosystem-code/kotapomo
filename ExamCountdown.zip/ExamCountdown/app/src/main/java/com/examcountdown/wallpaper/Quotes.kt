package com.examcountdown.wallpaper

object Quotes {
    private val motivation = listOf(
        "Small steps every day beat big plans someday.",
        "You don’t need to be perfect. You need to show up.",
        "Today’s effort is tomorrow’s confidence.",
        "One focused hour is worth three distracted ones.",
        "Discipline is choosing what you want most over what you want now.",
        "Progress, not perfection.",
        "Your future self is watching. Make them proud.",
        "Difficult doesn’t mean impossible. It means keep going.",
        "Study now. Celebrate later.",
        "Every page you finish is a page you’ll never fear.",
        "Be stronger than your excuses.",
        "Rest when needed, but never quit.",
        "Consistency turns ordinary days into results.",
        "The best time to start was yesterday. The next best is now.",
        "Trust the work you’ve already put in.",
        "Doubt will pass. Your preparation will stay.",
        "Focus on the next question, not the whole exam.",
        "You’ve survived every hard day so far.",
        "Calm mind, clear answers.",
        "Make today count.",
        "Hard work quietly builds loud results.",
        "Learn something new before you sleep.",
        "Slow progress is still progress.",
        "Your only competition is who you were yesterday.",
        "Breathe. Revise. Repeat.",
        "A little revision every day goes a long way.",
        "Believe in your preparation.",
        "Start where you are and keep moving.",
        "Dream big, study smart.",
        "Failure is only feedback. Learn and move on.",
        "Stay curious. Stay patient. Stay steady.",
        "Pressure is what turns effort into brilliance.",
        "Wake up with purpose.",
        "The effort you give today is a gift to your future.",
        "Make each day count, not just pass.",
        "Do it tired. Do it nervous. Just do it.",
        "You are closer than you were yesterday.",
        "Keep your goal bigger than your fear.",
        "Every expert once struggled with the basics.",
        "Sleep well, eat well, study well.",
        "Your hard work will speak on exam day.",
        "Turn the page, not the clock.",
        "Nothing is wasted when you keep learning.",
        "Be patient with yourself. Growth takes time.",
        "Put your phone down. Pick your dreams up.",
        "Stay positive and revise smartly.",
        "You have what it takes.",
        "One more chapter, one step closer.",
        "Success is small efforts repeated day after day.",
        "Own your preparation, own your day."
    )


    private val calm = listOf(
        "Breathe in slowly. You’re more ready than you feel.",
        "A calm mind remembers more.",
        "You can’t pour from an empty cup. Rest counts too.",
        "Let go of what you can’t control and study what you can.",
        "Nerves mean you care. Use that energy.",
        "One breath, one question, one step.",
        "It’s okay to take a break. Come back softer and stronger.",
        "Your worth is not a mark on a paper.",
        "Quiet the noise. Trust your preparation.",
        "Stretch, sip water, smile. Then keep going.",
        "Be kind to yourself today.",
        "Slow is smooth, and smooth is fast.",
        "You are allowed to feel nervous and still do well.",
        "Tonight, sleep. Tomorrow, shine.",
        "Peace comes from preparation and patience."
    )

    private val focus = listOf(
        "Close the tabs. Open the book.",
        "Do the hardest topic first.",
        "Deep work beats long hours.",
        "Set a timer. Start before you feel ready.",
        "One subject, one session, no distractions.",
        "Phone away. Eyes on the page.",
        "Write it down. Say it out loud. Test yourself.",
        "Recalling from memory beats re-reading.",
        "Plan the day, then follow the plan.",
        "Review today what you learned yesterday.",
        "Twenty-five minutes of focus is a win.",
        "Practise past papers like it’s the real exam.",
        "Fix your weak spots first.",
        "Small topics, finished fully.",
        "Protect your study time like an appointment."
    )

    private val hindi = listOf(
        "छोटे कदम रोज़ चलो, मंज़िल खुद पास आएगी।",
        "आज की मेहनत ही कल का आत्मविश्वास है।",
        "खुद पर भरोसा रखो, तैयारी पर भरोसा रखो।",
        "हार मत मानो, तुम सोच से ज़्यादा करीब हो।",
        "एक-एक पन्ना, एक-एक कदम।",
        "मेहनत चुपचाप होती है, नतीजे शोर करते हैं।",
        "आज का दिन बेकार मत जाने दो।",
        "डर को पीछे छोड़ो, किताब आगे बढ़ाओ।",
        "जो ठान लिया, उसे कर दिखाओ।",
        "धैर्य रखो, मेहनत रंग लाएगी।",
        "हर दिन थोड़ा बेहतर बनो।",
        "सपने बड़े रखो, मेहनत उससे भी बड़ी।",
        "गहरी साँस लो, फिर से शुरू करो।",
        "तुमने पहले भी मुश्किल दिन पार किए हैं।",
        "नियमितता ही सफलता की चाबी है।",
        "फ़ोन रखो, सपनों को उठाओ।",
        "आज पढ़ोगे तो कल चमकोगे।",
        "हर सवाल एक नया मौका है।",
        "शांत मन, साफ़ जवाब।",
        "अपनी तैयारी पर गर्व करो।"
    )

    val categories = listOf("Motivation", "Calm", "Focus", "Hindi", "Mixed")

    fun forDay(day: Long, cat: Int = 0): String {
        val list = when (cat) {
            1 -> calm
            2 -> focus
            3 -> hindi
            4 -> motivation + calm + focus
            else -> motivation
        }
        return list[Math.floorMod(day, list.size.toLong()).toInt()]
    }
}
