package com.examcountdown.wallpaper

import android.content.Context
import android.graphics.*
import android.net.Uri
import android.text.Layout
import androidx.exifinterface.media.ExifInterface
import java.io.File
import java.io.FileFilter

data class PhotoOpts(
    val style: Int = 0, val dim: Int = 25, val blur: Int = 0, val pos: Int = 1,
    val accent: Int = 0, val ink: Int = 0, val fx: Int = 50, val fy: Int = 50,
    val accentColor: Int = 0, val font: Int = 0
)

object Accents {
    val list = intArrayOf(
        0xFFFFFFFF.toInt(), 0xFF7CF0D4.toInt(), 0xFF64D2FF.toInt(), 0xFFA78BFA.toInt(),
        0xFFFF7AB6.toInt(), 0xFFFF9F43.toInt(), 0xFFFFD60A.toInt(), 0xFFFF5C5C.toInt()
    )
}

/** Keeps private copies of the user's photos inside the app. Nothing leaves the phone. */
object PhotoStore {
    private val cache = HashMap<String, Bitmap>()
    const val MAX_PHOTOS = 12

    fun files(ctx: Context): List<File> {
        val arr = ctx.filesDir.listFiles(FileFilter { f -> f.name.startsWith("bg_") && f.name.endsWith(".jpg") })
        return arr?.sortedBy { it.name } ?: emptyList()
    }

    fun count(ctx: Context) = files(ctx).size
    fun exists(ctx: Context) = count(ctx) > 0

    fun newestIndex(ctx: Context): Int {
        val fs = files(ctx)
        var best = 0
        for (i in fs.indices) if (fs[i].lastModified() >= fs[best].lastModified()) best = i
        return best
    }

    /** Which photo to use today: rotates daily when the slideshow is on. */
    fun indexFor(ctx: Context, s: Settings, today: Long): Int {
        val n = count(ctx)
        if (n == 0) return -1
        return if (s.slideshow) Math.floorMod(today, n.toLong()).toInt() else s.photoSel.coerceIn(0, n - 1)
    }

    fun remove(ctx: Context, i: Int) {
        files(ctx).getOrNull(i)?.delete()
        cache.clear()
    }

    fun import(ctx: Context, uri: Uri): Boolean {
        return try {
            if (count(ctx) >= MAX_PHOTOS) return false
            val cr = ctx.contentResolver
            var rot = 0
            cr.openInputStream(uri)?.use {
                val exif = ExifInterface(it)
                rot = when (exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270
                    else -> 0
                }
            }
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 3200) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            var bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return false
            if (rot != 0) {
                val m = Matrix(); m.postRotate(rot.toFloat())
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }
            val name = "bg_" + System.currentTimeMillis().toString().padStart(13, '0') + ".jpg"
            File(ctx.filesDir, name).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            bmp.recycle()
            cache.clear()
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Decodes photo #idx as small as possible while still covering tw x th. */
    fun load(ctx: Context, idx: Int, tw: Int, th: Int): Bitmap? {
        val f = files(ctx).getOrNull(idx) ?: return null
        return try {
            val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.path, b)
            var sample = 1
            while (b.outWidth / (sample * 2) >= tw && b.outHeight / (sample * 2) >= th) sample *= 2
            BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = sample })
        } catch (e: Exception) { null }
    }

    /** Small copy for fast on-screen previews. */
    fun cached(ctx: Context, idx: Int): Bitmap? {
        val f = files(ctx).getOrNull(idx) ?: return null
        val key = f.name + "|" + f.lastModified()
        val hit = cache[key]
        if (hit != null) return hit
        val b = load(ctx, idx, 360, 780)
        if (b != null) {
            if (cache.size >= 4) cache.clear()
            cache[key] = b
        }
        return b
    }

    fun thumb(ctx: Context, idx: Int): Bitmap? = load(ctx, idx, 160, 160)
}

object PhotoRenderer {
    val styleNames = listOf("Glass", "Minimal", "Ring", "Banner", "Poster", "Capsule")

    private class Ink(val text: Int, val sub: Int, val tint: Int, val track: Int)
    private val LIGHT = Ink(0xFFFFFFFF.toInt(), 0xCCFFFFFF.toInt(), 0x24FFFFFF, 0x44FFFFFF)
    private val DARK = Ink(0xFF14141A.toInt(), 0xAA20202C.toInt(), 0x66FFFFFF, 0x26000000)

    private class G(
        val c: Canvas, val p: Paint, val W: Float, val H: Float, val ink: Ink, val acc: Int,
        val glass: Bitmap?, val title: String, val num: String, val label: String, val days: Long,
        val frac: Float, val date: String, val cy: Float, val dx: Float, val font: Typeface?
    )

    private val thin = Typeface.create("sans-serif-thin", Typeface.NORMAL)
    private val light = Typeface.create("sans-serif-light", Typeface.NORMAL)
    private val medium = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    private val bold = Typeface.create("sans-serif", Typeface.BOLD)
    private val condensed = Typeface.create("sans-serif-condensed", Typeface.BOLD)
    private fun nf(g: G, d: Typeface): Typeface = g.font ?: d
    private val filt = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)

    // ------------------------------------------------------------ background
    private fun drawCover(c: Canvas, src: Bitmap, W: Float, H: Float, fx: Int, fy: Int) {
        val s = maxOf(W / src.width, H / src.height)
        val dx = (W - src.width * s) * (fx / 100f)
        val dy = (H - src.height * s) * (fy / 100f)
        val m = Matrix()
        m.setScale(s, s); m.postTranslate(dx, dy)
        c.drawBitmap(src, m, filt)
    }

    private fun fallback(c: Canvas, W: Float, H: Float) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(0f, 0f, W * 0.4f, H, Color.parseColor("#26305E"), Color.parseColor("#0B0C14"),
            Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, W, H, p)
        p.shader = RadialGradient(W * 0.8f, H * 0.2f, W * 0.8f, Color.parseColor("#667C5CFF"),
            Color.parseColor("#007C5CFF"), Shader.TileMode.CLAMP)
        c.drawCircle(W * 0.8f, H * 0.2f, W * 0.8f, p)
    }

    private fun smoothScale(src: Bitmap, tw: Int, th: Int): Bitmap {
        var cur = src
        while (cur.width / 2 >= tw && cur.height / 2 >= th) {
            val n = Bitmap.createScaledBitmap(cur, cur.width / 2, cur.height / 2, true)
            if (cur !== src) cur.recycle()
            cur = n
        }
        while (cur.width * 2 <= tw && cur.height * 2 <= th) {
            val n = Bitmap.createScaledBitmap(cur, cur.width * 2, cur.height * 2, true)
            if (cur !== src) cur.recycle()
            cur = n
        }
        if (cur.width != tw || cur.height != th) {
            val n = Bitmap.createScaledBitmap(cur, tw, th, true)
            if (cur !== src) cur.recycle()
            cur = n
        }
        return cur
    }

    /** Soft blur made by shrinking and re-growing the picture in small steps. */
    private fun blurred(src: Bitmap, factor: Int): Bitmap {
        if (factor <= 1) return src.copy(Bitmap.Config.ARGB_8888, false)
        val small = smoothScale(src, maxOf(2, src.width / factor), maxOf(2, src.height / factor))
        val big = smoothScale(small, src.width, src.height)
        if (small !== big && small !== src) small.recycle()
        return big
    }

    private fun prepareBackground(bmp: Bitmap, photo: Bitmap?, o: PhotoOpts, dim: Int) {
        val c = Canvas(bmp)
        val W = bmp.width.toFloat(); val H = bmp.height.toFloat()
        if (photo != null) drawCover(c, photo, W, H, o.fx, o.fy) else fallback(c, W, H)
        if (o.blur > 0) {
            val b = blurred(bmp, 1 + o.blur)
            c.drawBitmap(b, 0f, 0f, null)
            b.recycle()
        }
        c.drawColor(Color.argb((dim * 255 / 100).coerceIn(0, 235), 0, 0, 0))
    }

    private fun inkFor(bg: Bitmap, choice: Int): Ink {
        if (choice == 1) return LIGHT
        if (choice == 2) return DARK
        val s = Bitmap.createScaledBitmap(bg, 8, 16, true)
        var sum = 0f
        for (x in 0 until 8) for (y in 0 until 16) {
            val px = s.getPixel(x, y)
            sum += (0.299f * Color.red(px) + 0.587f * Color.green(px) + 0.114f * Color.blue(px)) / 255f
        }
        if (s !== bg) s.recycle()
        return if (sum / 128f > 0.62f) DARK else LIGHT
    }

    // ---------------------------------------------------------------- public
    fun render(
        photo: Bitmap?, w: Int, h: Int, o: PhotoOpts, name: String, days: Long,
        fraction: Float, dateText: String, quote: String?, d: Disp = Disp.of(days)
    ): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        prepareBackground(bmp, photo, o, o.dim)
        val ink = inkFor(bmp, o.ink)
        val acc = if (o.accentColor != 0) o.accentColor else Accents.list[o.accent.coerceIn(0, Accents.list.size - 1)]
        val needGlass = o.style == 0 || o.style == 2 || o.style == 3 || o.style == 5
        val glass = if (needGlass) blurred(bmp, 14) else null
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val FW = w.toFloat(); val H = h.toFloat()
        val W = if (FW > H) H * 0.56f else FW
        val dx = (FW - W) / 2f
        val cy = H * when (o.pos) { 0 -> 0.33f; 2 -> 0.74f; else -> 0.52f }
        val g = G(c, p, W, H, ink, acc, glass, name.trim().ifEmpty { "EXAM" }.uppercase(),
            d.num, d.label, days, fraction.coerceIn(0f, 1f), dateText, cy, dx, Fonts.face(o.font))

        c.save()
        c.translate(dx, 0f)
        if (o.style == 4) scrim(g)
        val bottom = when (o.style) {
            0 -> glassCard(g)
            1 -> minimal(g)
            2 -> ringStyle(g)
            3 -> banner(g)
            4 -> poster(g)
            else -> capsule(g)
        }
        if (!quote.isNullOrEmpty()) {
            val left = o.style == 4
            val width = ((if (left) 0.84f else 0.76f) * W).toInt()
            Renderer.wrapped(c, quote, if (left) W * 0.08f else (W - width) / 2f, bottom + W * 0.07f, width,
                W * 0.04f, ink.sub,
                if (left) Layout.Alignment.ALIGN_NORMAL else Layout.Alignment.ALIGN_CENTER,
                3, H * 0.93f, true, true)
        }
        c.restore()
        glass?.recycle()
        return bmp
    }

    /** Background and colours for widgets that sit on the user's photo. */
    fun widgetBackground(photo: Bitmap?, o: PhotoOpts, w: Int, h: Int): Pair<(Canvas, Float, Float) -> Unit, Theme> {
        val bg = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        prepareBackground(bg, photo, o, maxOf(o.dim, 30))
        val ink = inkFor(bg, o.ink)
        val acc = if (o.accentColor != 0) o.accentColor else Accents.list[o.accent.coerceIn(0, Accents.list.size - 1)]
        val th = Theme("Photo", 0, 0, ink.text, ink.sub, acc, ink.track, thin, -1)
        val draw: (Canvas, Float, Float) -> Unit = { cv, _, _ -> cv.drawBitmap(bg, 0f, 0f, null) }
        return Pair(draw, th)
    }

    // --------------------------------------------------------------- helpers
    private fun txt(
        g: G, s: String, x: Float, y: Float, size: Float, color: Int, tf: Typeface,
        spacing: Float = 0f, align: Paint.Align = Paint.Align.CENTER, maxW: Float = 0f, shadow: Boolean = false
    ) {
        val p = g.p
        p.style = Paint.Style.FILL; p.typeface = tf; p.letterSpacing = spacing; p.color = color
        p.textAlign = align; p.textSize = size
        if (maxW > 0f) {
            val m = p.measureText(s)
            if (m > maxW) p.textSize = size * maxW / m
        }
        if (shadow) p.setShadowLayer(g.W * 0.03f, 0f, g.W * 0.01f, 0x40000000)
        g.c.drawText(s, x, y, p)
        if (shadow) p.clearShadowLayer()
        p.letterSpacing = 0f
    }

    private fun fitSize(g: G, s: String, size: Float, maxW: Float, tf: Typeface, spacing: Float = 0f): Float {
        g.p.typeface = tf; g.p.letterSpacing = spacing; g.p.textSize = size
        val m = g.p.measureText(s)
        g.p.letterSpacing = 0f
        return if (m > maxW) size * maxW / m else size
    }

    private fun roundPath(r: RectF, rad: Float): Path {
        val path = Path()
        path.addRoundRect(r, rad, rad, Path.Direction.CW)
        return path
    }

    private fun frost(g: G, path: Path) {
        val p = g.p
        p.style = Paint.Style.FILL
        if (g.glass != null) {
            val sh = BitmapShader(g.glass, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
            val m = Matrix()
            m.setTranslate(-g.dx, 0f)
            sh.setLocalMatrix(m)
            p.shader = sh
            g.c.drawPath(path, p)
            p.shader = null
        }
        p.color = g.ink.tint
        g.c.drawPath(path, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = g.W * 0.0035f; p.color = 0x55FFFFFF
        g.c.drawPath(path, p)
        p.style = Paint.Style.FILL
    }

    private fun bar(g: G, x1: Float, x2: Float, y: Float, th: Float) {
        val p = g.p
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND; p.strokeWidth = th
        p.color = g.ink.track; g.c.drawLine(x1, y, x2, y, p)
        p.color = g.acc; g.c.drawLine(x1, y, x1 + (x2 - x1) * g.frac.coerceIn(0.02f, 1f), y, p)
        p.style = Paint.Style.FILL
    }

    private fun arc(g: G, cx: Float, cy: Float, r: Float, sw: Float) {
        val p = g.p
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND; p.strokeWidth = sw
        p.color = g.ink.track; g.c.drawCircle(cx, cy, r, p)
        p.color = g.acc
        g.c.drawArc(RectF(cx - r, cy - r, cx + r, cy + r), -90f, 360f * g.frac.coerceIn(0.02f, 1f), false, p)
        p.style = Paint.Style.FILL
    }

    private fun scrim(g: G) {
        val col = if (g.ink === LIGHT) 0x99000000.toInt() else 0x66FFFFFF
        g.p.style = Paint.Style.FILL
        g.p.shader = LinearGradient(0f, g.H * 0.4f, 0f, g.H, col and 0x00FFFFFF, col, Shader.TileMode.CLAMP)
        g.c.drawRect(-g.dx, g.H * 0.4f, g.W + g.dx, g.H, g.p)
        g.p.shader = null
    }

    // ---------------------------------------------------------------- styles
    private fun glassCard(g: G): Float {
        val W = g.W; val H = g.H; val cx = W / 2f
        val cw = W * 0.80f; val ch = W * 0.74f
        val top = (g.cy - ch / 2f).coerceIn(H * 0.07f, H * 0.93f - ch)
        val left = (W - cw) / 2f
        frost(g, roundPath(RectF(left, top, left + cw, top + ch), W * 0.08f))
        txt(g, g.title, cx, top + ch * 0.13f, W * 0.036f, g.ink.sub, medium, 0.3f, maxW = cw * 0.84f)
        val ns = fitSize(g, g.num, W * 0.30f, cw * 0.7f, nf(g, thin))
        txt(g, g.num, cx, top + ch * 0.60f, ns, g.ink.text, nf(g, thin))
        txt(g, g.label, cx, top + ch * 0.72f, W * 0.034f, g.acc, medium, 0.25f)
        bar(g, cx - cw * 0.35f, cx + cw * 0.35f, top + ch * 0.81f, W * 0.011f)
        txt(g, g.date, cx, top + ch * 0.93f, W * 0.03f, g.ink.sub, medium, 0.15f)
        return top + ch
    }

    private fun minimal(g: G): Float {
        val W = g.W; val cx = W / 2f
        val ns = fitSize(g, g.num, W * 0.50f, W * 0.86f, nf(g, thin))
        val base = g.cy + ns * 0.35f
        txt(g, g.title, cx, base - ns * 0.74f - W * 0.05f, W * 0.04f, g.ink.sub, medium, 0.3f,
            maxW = W * 0.8f, shadow = true)
        txt(g, g.num, cx, base, ns, g.ink.text, nf(g, thin), shadow = true)
        txt(g, g.label, cx, base + W * 0.10f, W * 0.04f, g.acc, medium, 0.28f, shadow = true)
        txt(g, g.date, cx, base + W * 0.16f, W * 0.032f, g.ink.sub, medium, 0.15f, shadow = true)
        bar(g, cx - W * 0.18f, cx + W * 0.18f, base + W * 0.22f, W * 0.008f)
        return base + W * 0.22f
    }

    private fun ringStyle(g: G): Float {
        val W = g.W; val cx = W / 2f; val R = W * 0.35f
        val cy = g.cy.coerceIn(g.H * 0.07f + R + W * 0.10f, g.H * 0.93f - R - W * 0.09f)
        val circle = Path()
        circle.addCircle(cx, cy, R, Path.Direction.CW)
        frost(g, circle)
        arc(g, cx, cy, R * 0.86f, W * 0.018f)
        val ns = fitSize(g, g.num, R * 0.80f, R * 1.15f, nf(g, thin))
        txt(g, g.num, cx, cy + ns * 0.30f, ns, g.ink.text, nf(g, thin))
        txt(g, g.label, cx, cy + ns * 0.30f + R * 0.27f, R * 0.105f, g.acc, medium, 0.22f)
        txt(g, g.title, cx, cy - R - W * 0.06f, W * 0.04f, g.ink.text, medium, 0.25f, maxW = W * 0.8f, shadow = true)
        val dateY = cy + R + W * 0.09f
        txt(g, g.date, cx, dateY, W * 0.032f, g.ink.sub, medium, 0.15f, shadow = true)
        return dateY
    }

    private fun banner(g: G): Float {
        val W = g.W; val H = g.H
        val bh = W * 0.34f; val left = W * 0.06f; val right = W * 0.94f
        val top = (g.cy - bh / 2f).coerceIn(H * 0.07f, H * 0.93f - bh)
        frost(g, roundPath(RectF(left, top, right, top + bh), W * 0.07f))
        val ns = fitSize(g, g.num, W * 0.24f, W * 0.27f, nf(g, light))
        txt(g, g.num, left + W * 0.19f, top + bh / 2f + ns * 0.34f, ns, g.ink.text, nf(g, light))
        g.p.style = Paint.Style.STROKE; g.p.strokeWidth = W * 0.003f; g.p.color = g.ink.track
        g.c.drawLine(left + W * 0.385f, top + bh * 0.2f, left + W * 0.385f, top + bh * 0.8f, g.p)
        g.p.style = Paint.Style.FILL
        val x0 = left + W * 0.44f; val tw = right - W * 0.05f - x0
        txt(g, g.title, x0, top + bh * 0.30f, W * 0.042f, g.ink.text, medium, 0.12f, Paint.Align.LEFT, tw)
        txt(g, g.label, x0, top + bh * 0.50f, W * 0.032f, g.acc, medium, 0.22f, Paint.Align.LEFT)
        txt(g, g.date, x0, top + bh * 0.68f, W * 0.03f, g.ink.sub, medium, 0.12f, Paint.Align.LEFT)
        bar(g, x0, x0 + tw, top + bh * 0.84f, W * 0.011f)
        return top + bh
    }

    private fun poster(g: G): Float {
        val W = g.W; val x = W * 0.08f
        val ns = fitSize(g, g.num, W * 0.58f, W * 0.84f, nf(g, condensed))
        val shift = maxOf(0f, g.cy + ns * 0.30f + W * 0.375f - g.H * 0.93f)
        val base = g.cy + ns * 0.30f - shift
        txt(g, g.num, x, base, ns, g.ink.text, nf(g, condensed), align = Paint.Align.LEFT, shadow = true)
        g.p.style = Paint.Style.FILL; g.p.color = g.acc
        g.c.drawRoundRect(RectF(x, base + W * 0.06f, x + W * 0.20f, base + W * 0.076f), W * 0.008f, W * 0.008f, g.p)
        val nameY = base + W * 0.17f
        txt(g, g.title, x, nameY, W * 0.06f, g.ink.text, condensed, 0.06f, Paint.Align.LEFT, W * 0.84f, true)
        val label = g.label
        val labelY = nameY + W * 0.075f
        txt(g, label, x, labelY, W * 0.034f, g.acc, medium, 0.25f, Paint.Align.LEFT, shadow = true)
        val dateY = labelY + W * 0.06f
        txt(g, g.date, x, dateY, W * 0.03f, g.ink.sub, medium, 0.15f, Paint.Align.LEFT, shadow = true)
        val barY = dateY + W * 0.07f
        bar(g, x, W - x, barY, W * 0.010f)
        return barY
    }

    private fun capsule(g: G): Float {
        val W = g.W; val cy = g.cy
        val s1 = W * 0.07f
        val t2 = g.label + "  \u00B7  " + g.title
        var s2 = W * 0.032f
        val ringD = W * 0.085f; val gap = W * 0.03f; val pad = W * 0.05f
        g.p.typeface = nf(g, bold); g.p.letterSpacing = 0f; g.p.textSize = s1
        val w1 = g.p.measureText(g.num)
        var w2 = 0f
        while (true) {
            g.p.typeface = medium; g.p.letterSpacing = 0.15f; g.p.textSize = s2
            w2 = g.p.measureText(t2)
            g.p.letterSpacing = 0f
            val total = pad + ringD + gap + w1 + gap + w2 + pad
            if (total <= W * 0.9f || s2 <= W * 0.02f) break
            s2 *= 0.93f
        }
        val total = pad + ringD + gap + w1 + gap + w2 + pad
        val h = W * 0.15f
        val left = (W - total) / 2f
        frost(g, roundPath(RectF(left, cy - h / 2f, left + total, cy + h / 2f), h / 2f))
        arc(g, left + pad + ringD / 2f, cy, ringD / 2f, W * 0.012f)
        val nx = left + pad + ringD + gap
        txt(g, g.num, nx, cy + s1 * 0.35f, s1, g.ink.text, nf(g, bold), align = Paint.Align.LEFT)
        txt(g, t2, nx + w1 + gap, cy + s2 * 0.35f, s2, g.ink.sub, medium, 0.15f, Paint.Align.LEFT)
        return cy + h / 2f
    }
}
