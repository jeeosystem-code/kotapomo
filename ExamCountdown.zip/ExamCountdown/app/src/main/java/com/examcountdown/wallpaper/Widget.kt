package com.examcountdown.wallpaper

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.RemoteViews
import java.time.LocalDate

abstract class BaseWidget : AppWidgetProvider() {
    abstract val kind: Int

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) WidgetUpdater.update(context, appWidgetManager, id, kind)
    }

    override fun onAppWidgetOptionsChanged(
        context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int, newOptions: Bundle
    ) {
        WidgetUpdater.update(context, appWidgetManager, appWidgetId, kind)
    }

    override fun onEnabled(context: Context) {
        Scheduler.schedule(context)
    }
}

class CountdownWidget : BaseWidget() { override val kind = 0 }
class TinyWidget : BaseWidget() { override val kind = 1 }
class CalendarWidget : BaseWidget() { override val kind = 2 }
class ListWidget : BaseWidget() { override val kind = 3 }

object WidgetUpdater {
    fun update(ctx: Context, mgr: AppWidgetManager, id: Int, kind: Int) {
        val s = Prefs.load(ctx)
        val today = LocalDate.now().toEpochDay()
        val shown = if (s.examDay < 0 && s.extra.isEmpty()) s.copy(examDay = today + 30, name = "Tap to set up") else s

        val opts = mgr.getAppWidgetOptions(id)
        val d = ctx.resources.displayMetrics.density
        val minDp = if (kind == 1) 30 else 60
        val wDp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, if (kind == 1) 60 else 160).coerceAtLeast(minDp)
        val hDp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, if (kind == 1) 60 else 160).coerceAtLeast(minDp)
        var w = (wDp * d).toInt()
        var h = (hDp * d).toInt()
        val maxPixels = 2_500_000
        while (w.toLong() * h > maxPixels) { w = (w * 0.9f).toInt(); h = (h * 0.9f).toInt() }

        val allowQuote = kind == 0 && (wDp >= 230 || (wDp >= 150 && hDp >= 150))
        val bmp = Updater.widgetBitmap(ctx, shown, kind, w, h, today, allowQuote, false)

        val views = RemoteViews(ctx.packageName, R.layout.widget)
        views.setImageViewBitmap(R.id.widget_img, bmp)
        val open = Intent(ctx, MainActivity::class.java)
        val pi = PendingIntent.getActivity(ctx, 0, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        views.setOnClickPendingIntent(R.id.widget_root, pi)
        mgr.updateAppWidget(id, views)
    }
}
