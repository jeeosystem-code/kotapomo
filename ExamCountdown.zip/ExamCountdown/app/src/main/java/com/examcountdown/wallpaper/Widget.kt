package com.examcountdown.wallpaper

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.RemoteViews
import java.time.LocalDate

class CountdownWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) WidgetUpdater.update(context, appWidgetManager, id)
    }

    override fun onAppWidgetOptionsChanged(
        context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int, newOptions: Bundle
    ) {
        WidgetUpdater.update(context, appWidgetManager, appWidgetId)
    }

    override fun onEnabled(context: Context) {
        Scheduler.schedule(context)
    }
}

object WidgetUpdater {
    fun update(ctx: Context, mgr: AppWidgetManager, id: Int) {
        val s = Prefs.load(ctx)
        val today = LocalDate.now().toEpochDay()
        val shown = if (s.examDay < 0) s.copy(examDay = today + 30, name = "Tap to set up") else s

        val opts = mgr.getAppWidgetOptions(id)
        val d = ctx.resources.displayMetrics.density
        val wDp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 160).coerceAtLeast(60)
        val hDp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 160).coerceAtLeast(60)
        var w = (wDp * d).toInt()
        var h = (hDp * d).toInt()
        val maxPixels = 2_500_000
        while (w.toLong() * h > maxPixels) { w = (w * 0.9f).toInt(); h = (h * 0.9f).toInt() }

        val allowQuote = wDp >= 230 || (wDp >= 150 && hDp >= 150)
        val bmp = Updater.widgetBitmap(ctx, shown, Updater.activeIndex(shown), w, h, today, allowQuote, false)

        val views = RemoteViews(ctx.packageName, R.layout.widget)
        views.setImageViewBitmap(R.id.widget_img, bmp)
        val open = Intent(ctx, MainActivity::class.java)
        val pi = PendingIntent.getActivity(ctx, 0, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        views.setOnClickPendingIntent(R.id.widget_root, pi)
        mgr.updateAppWidget(id, views)
    }
}
