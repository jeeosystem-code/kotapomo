package com.examcountdown.wallpaper

import android.app.Activity
import android.app.DatePickerDialog
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputFilter
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.*
import androidx.core.widget.doAfterTextChanged
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

class MainActivity : Activity() {
    private val BG = Color.parseColor("#0E0F14")
    private val CARD = Color.parseColor("#1A1C26")
    private val ACC = Color.parseColor("#7C5CFF")
    private val MUTED = Color.parseColor("#8B8FA3")
    private lateinit var cfg: Settings
    private val imgs = ArrayList<ImageView>()
    private val wraps = ArrayList<LinearLayout>()
    private val dots = ArrayList<View>()
    private lateinit var dateBtn: Button
    private lateinit var widgetImg: ImageView
    private lateinit var row: LinearLayout
    private lateinit var rowLabel: TextView
    private lateinit var photoPanel: LinearLayout
    private lateinit var btnThemes: Button
    private lateinit var btnPhoto: Button
    private var aspect = 2.1f

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun round(color: Int, r: Int, stroke: Int = 0, sc: Int = 0) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(r).toFloat(); if (stroke > 0) setStroke(stroke, sc)
    }
    private fun tv(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }
    private fun lp(top: Int = 0, h: Int = ViewGroup.LayoutParams.WRAP_CONTENT) =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h).apply { topMargin = dp(top) }

    private fun commit() {
        if (cfg.startDay < 0) cfg.startDay = LocalDate.now().toEpochDay()
        Prefs.save(this, cfg)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        cfg = Prefs.load(this)
        val today = LocalDate.now().toEpochDay()
        if (cfg.examDay < 0) cfg.examDay = today + 60
        val sz = Screen.size(this)
        aspect = sz.second.toFloat() / sz.first.toFloat()
        window.statusBarColor = BG; window.navigationBarColor = BG

        val root = ScrollView(this).apply { setBackgroundColor(BG) }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(48), dp(20), dp(32))
        }
        root.addView(col)
        col.addView(tv("Exam Countdown", 30f, Color.WHITE, true))
        col.addView(tv("Wallpaper, widget and a fresh quote every day.", 14f, MUTED).apply {
            setPadding(0, dp(4), 0, dp(24))
        })

        col.addView(tv("EXAM NAME", 12f, MUTED, true))
        val nameEt = EditText(this).apply {
            setText(cfg.name); hint = "e.g. Board Exams"
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            background = round(CARD, 14); setPadding(dp(16), dp(14), dp(16), dp(14))
            setSingleLine(); filters = arrayOf(InputFilter.LengthFilter(28))
            doAfterTextChanged { cfg.name = it?.toString() ?: ""; refresh() }
        }
        col.addView(nameEt, lp(top = 8))

        col.addView(tv("EXAM DATE", 12f, MUTED, true), lp(top = 20))
        dateBtn = Button(this).apply {
            isAllCaps = false; setTextColor(Color.WHITE); textSize = 16f
            background = round(CARD, 14)
            setOnClickListener {
                val d = LocalDate.ofEpochDay(cfg.examDay)
                val dlg = DatePickerDialog(this@MainActivity, { _, y, m, day ->
                    cfg.examDay = LocalDate.of(y, m + 1, day).toEpochDay()
                    cfg.startDay = -1
                    updateDate(); refresh()
                }, d.year, d.monthValue - 1, d.dayOfMonth)
                dlg.datePicker.minDate = System.currentTimeMillis() - 1000
                dlg.show()
            }
        }
        col.addView(dateBtn, lp(top = 8))

        col.addView(tv("BACKGROUND", 12f, MUTED, true), lp(top = 20))
        val seg = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        btnThemes = Button(this).apply {
            text = "Gradient themes"; isAllCaps = false; setTextColor(Color.WHITE)
            setOnClickListener { setMode(0) }
        }
        btnPhoto = Button(this).apply {
            text = "My photo"; isAllCaps = false; setTextColor(Color.WHITE)
            setOnClickListener { setMode(1) }
        }
        seg.addView(btnThemes, LinearLayout.LayoutParams(0, dp(48), 1f).apply { rightMargin = dp(8) })
        seg.addView(btnPhoto, LinearLayout.LayoutParams(0, dp(48), 1f))
        col.addView(seg, lp(top = 8))

        photoPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        col.addView(photoPanel, lp())

        rowLabel = tv("THEME  (swipe for more)", 12f, MUTED, true)
        col.addView(rowLabel, lp(top = 20))
        row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        col.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) }, lp(top = 8))

        col.addView(tv("DAILY QUOTE", 12f, MUTED, true), lp(top = 20))
        val sw = Switch(this).apply {
            text = "Show a new quote on wallpaper and widget"
            setTextColor(Color.WHITE); isChecked = cfg.quote
            setOnCheckedChangeListener { _, v -> cfg.quote = v; refresh() }
        }
        col.addView(sw, lp(top = 8))

        col.addView(tv("APPLY WALLPAPER TO", 12f, MUTED, true), lp(top = 20))
        val rg = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        listOf("Home", "Lock", "Both").forEachIndexed { i, label ->
            rg.addView(RadioButton(this).apply {
                id = 100 + i; text = label; setTextColor(Color.WHITE)
                isChecked = (cfg.target == i)
            })
        }
        rg.setOnCheckedChangeListener { _, id -> cfg.target = id - 100 }
        col.addView(rg, lp(top = 8))

        val applyBtn = Button(this).apply {
            text = "Set wallpaper"; isAllCaps = false; textSize = 17f; setTextColor(Color.WHITE)
            background = round(ACC, 16)
            setOnClickListener {
                if (cfg.mode == 1 && !PhotoStore.exists(this@MainActivity)) {
                    Toast.makeText(this@MainActivity, "Choose a photo first.", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                cfg.last = -1
                commit()
                Scheduler.schedule(this@MainActivity)
                isEnabled = false
                Thread {
                    val ok = try { Updater.apply(this@MainActivity, true) } catch (e: Exception) { false }
                    runOnUiThread {
                        isEnabled = true
                        Toast.makeText(this@MainActivity,
                            if (ok) "Wallpaper set. It will update daily." else "Could not set wallpaper.",
                            Toast.LENGTH_LONG).show()
                    }
                }.start()
            }
        }
        col.addView(applyBtn, lp(top = 16, h = dp(56)))
        col.addView(tv("Made at your exact screen size, so it stays still when you swipe between home screens.",
            12f, MUTED).apply { setPadding(0, dp(8), 0, 0) })

        col.addView(tv("WIDGET", 12f, MUTED, true), lp(top = 28))
        widgetImg = ImageView(this).apply { adjustViewBounds = true }
        col.addView(widgetImg, lp(top = 8))
        col.addView(tv("Resize it on your home screen. Wide widgets also show the daily quote.",
            12f, MUTED).apply { setPadding(0, dp(6), 0, 0) })
        val addW = Button(this).apply {
            text = "Add widget to home screen"; isAllCaps = false; textSize = 16f; setTextColor(Color.WHITE)
            background = round(CARD, 16, dp(1), ACC)
            setOnClickListener {
                commit()
                val mgr = AppWidgetManager.getInstance(this@MainActivity)
                if (mgr.isRequestPinAppWidgetSupported) {
                    mgr.requestPinAppWidget(ComponentName(this@MainActivity, CountdownWidget::class.java), null, null)
                } else {
                    Toast.makeText(this@MainActivity,
                        "Long-press your home screen, tap Widgets, then pick Exam Countdown.",
                        Toast.LENGTH_LONG).show()
                }
            }
        }
        col.addView(addW, lp(top = 12, h = dp(52)))

        setContentView(root)
        updateDate()
        buildPhotoPanel()
        setMode(cfg.mode)
    }

    // ------------------------------------------------------------ photo panel
    private fun seekRow(label: String, maxV: Int, value: Int, onSet: (Int) -> Unit): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(12), 0, 0) }
        val t = tv("$label: $value", 13f, Color.WHITE)
        val sb = SeekBar(this).apply {
            max = maxV; progress = value
            progressTintList = ColorStateList.valueOf(ACC)
            thumbTintList = ColorStateList.valueOf(ACC)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, p: Int, fromUser: Boolean) {
                    t.text = "$label: $p"; onSet(p)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) { refresh() }
            })
        }
        box.addView(t); box.addView(sb)
        return box
    }

    private fun radios(base: Int, labels: List<String>, selected: Int, onPick: (Int) -> Unit): RadioGroup {
        val g = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        labels.forEachIndexed { i, l ->
            g.addView(RadioButton(this).apply {
                id = base + i; text = l; setTextColor(Color.WHITE); isChecked = (i == selected)
            })
        }
        g.setOnCheckedChangeListener { _, id -> onPick(id - base); refresh() }
        return g
    }

    private fun paintDots() {
        dots.forEachIndexed { i, v ->
            v.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Accents.list[i])
                setStroke(dp(if (i == cfg.acc) 3 else 1),
                    if (i == cfg.acc) Color.parseColor("#7C5CFF") else Color.parseColor("#55FFFFFF"))
            }
        }
    }

    private fun buildPhotoPanel() {
        photoPanel.removeAllViews(); dots.clear()
        val has = PhotoStore.exists(this)
        val pick = Button(this).apply {
            text = if (has) "Change photo" else "Choose a photo"
            isAllCaps = false; textSize = 16f; setTextColor(Color.WHITE)
            background = round(CARD, 16, dp(1), ACC)
            setOnClickListener { pickPhoto() }
        }
        photoPanel.addView(pick, lp(top = 14, h = dp(52)))
        photoPanel.addView(tv("Your photo stays on your phone. It is never uploaded.", 12f, MUTED)
            .apply { setPadding(0, dp(6), 0, 0) })
        photoPanel.addView(seekRow("Darken", 70, cfg.dim) { cfg.dim = it })
        photoPanel.addView(seekRow("Blur", 20, cfg.blur) { cfg.blur = it })
        photoPanel.addView(seekRow("Move photo left / right", 100, cfg.fx) { cfg.fx = it })
        photoPanel.addView(seekRow("Move photo up / down", 100, cfg.fy) { cfg.fy = it })

        photoPanel.addView(tv("OVERLAY POSITION", 12f, MUTED, true), lp(top = 18))
        photoPanel.addView(radios(200, listOf("Top", "Middle", "Bottom"), cfg.pos) { cfg.pos = it }, lp(top = 6))
        photoPanel.addView(tv("TEXT COLOUR", 12f, MUTED, true), lp(top = 14))
        photoPanel.addView(radios(300, listOf("Auto", "Light", "Dark"), cfg.ink) { cfg.ink = it }, lp(top = 6))
        photoPanel.addView(tv("ACCENT COLOUR", 12f, MUTED, true), lp(top = 14))
        val sw = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        Accents.list.forEachIndexed { i, _ ->
            val v = View(this)
            v.setOnClickListener { cfg.acc = i; paintDots(); refresh() }
            dots.add(v)
            sw.addView(v, LinearLayout.LayoutParams(dp(34), dp(34)).apply { rightMargin = dp(10) })
        }
        photoPanel.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(sw) }, lp(top = 8))
        paintDots()
    }

    private fun pickPhoto() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "image/*"
        }
        try { startActivityForResult(i, 42) } catch (e: Exception) {
            Toast.makeText(this, "No photo picker found on this phone.", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 42 || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        Toast.makeText(this, "Loading photo...", Toast.LENGTH_SHORT).show()
        Thread {
            val ok = PhotoStore.import(this, uri)
            runOnUiThread {
                if (ok) {
                    cfg.fx = 50; cfg.fy = 50
                    buildPhotoPanel()
                    setMode(1)
                } else {
                    Toast.makeText(this, "Could not read that photo.", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    // ------------------------------------------------------------- mode / cards
    private fun setMode(m: Int) {
        cfg.mode = m
        photoPanel.visibility = if (m == 1) View.VISIBLE else View.GONE
        btnThemes.background = round(if (m == 0) ACC else CARD, 14)
        btnPhoto.background = round(if (m == 1) ACC else CARD, 14)
        buildCards()
        select()
    }

    private fun selIndex() = if (cfg.mode == 1) cfg.style else cfg.theme

    private fun buildCards() {
        row.removeAllViews(); imgs.clear(); wraps.clear()
        val names = if (cfg.mode == 1) PhotoRenderer.styleNames else Themes.all.map { it.name }
        rowLabel.text = if (cfg.mode == 1) "OVERLAY STYLE  (swipe for more)" else "THEME  (swipe for more)"
        val cardW = dp(112)
        val cardH = (cardW * aspect).toInt()
        names.forEachIndexed { i, nm ->
            val wrap = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(4), dp(4), dp(4), dp(8))
                setOnClickListener { if (cfg.mode == 1) cfg.style = i else cfg.theme = i; select() }
            }
            val iv = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                outlineProvider = ViewOutlineProvider.BACKGROUND
                background = round(Color.DKGRAY, 14); clipToOutline = true
            }
            wrap.addView(iv, LinearLayout.LayoutParams(cardW, cardH))
            wrap.addView(tv(nm, 12f, Color.WHITE).apply { setPadding(0, dp(6), 0, 0) })
            imgs.add(iv); wraps.add(wrap)
            row.addView(wrap, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(8) })
        }
    }

    private fun updateDate() {
        dateBtn.text = LocalDate.ofEpochDay(cfg.examDay)
            .format(DateTimeFormatter.ofPattern("EEEE, dd MMM yyyy", Locale.getDefault()))
    }

    private fun select() {
        wraps.forEachIndexed { i, w ->
            w.background = round(Color.TRANSPARENT, 18, dp(2), if (i == selIndex()) ACC else Color.TRANSPARENT)
        }
        refresh()
    }

    private fun refresh() {
        if (!::widgetImg.isInitialized || imgs.isEmpty()) return
        val today = LocalDate.now().toEpochDay()
        val pw = 240
        val ph = (pw * aspect).toInt()
        imgs.forEachIndexed { i, iv -> iv.setImageBitmap(Updater.bitmapFor(this, cfg, i, pw, ph, today, true)) }
        widgetImg.setImageBitmap(Updater.widgetBitmap(this, cfg, selIndex(), 640, 300, today, true, true))
    }
}
