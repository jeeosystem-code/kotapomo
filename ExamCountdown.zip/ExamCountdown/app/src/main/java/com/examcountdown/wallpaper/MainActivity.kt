package com.examcountdown.wallpaper

import android.app.Activity
import android.app.DatePickerDialog
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputFilter
import android.view.Gravity
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.*
import androidx.core.widget.doAfterTextChanged
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

class MainActivity : Activity() {
    private val BG = Color.parseColor("#0E0F14")
    private val CARD = Color.parseColor("#1A1C26")
    private val ACC = Color.parseColor("#7C5CFF")
    private val MUTED = Color.parseColor("#8B8FA3")
    private lateinit var cfg: Settings
    private val imgs = ArrayList<ImageView>()
    private val wraps = ArrayList<LinearLayout>()
    private lateinit var dateBtn: Button

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun round(color: Int, r: Int, stroke: Int = 0, sc: Int = 0) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(r).toFloat(); if (stroke > 0) setStroke(stroke, sc)
    }
    private fun tv(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }
    private fun lp(top: Int = 0, h: Int = ViewGroup.LayoutParams.WRAP_CONTENT) =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h).apply { topMargin = dp(top) }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        cfg = Prefs.load(this)
        val today = LocalDate.now().toEpochDay()
        if (cfg.examDay < 0) cfg.examDay = today + 60
        window.statusBarColor = BG; window.navigationBarColor = BG

        val root = ScrollView(this).apply { setBackgroundColor(BG) }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(48), dp(20), dp(32))
        }
        root.addView(col)
        col.addView(tv("Exam Countdown", 30f, Color.WHITE, true))
        col.addView(tv("Your wallpaper, counting down. It updates itself every day.", 14f, MUTED).apply {
            setPadding(0, dp(4), 0, dp(24))
        })

        col.addView(tv("EXAM NAME", 12f, MUTED, true))
        val nameEt = EditText(this).apply {
            setText(cfg.name); hint = "e.g. Board Exams"
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            background = round(CARD, 14); setPadding(dp(16), dp(14), dp(16), dp(14))
            setSingleLine(); filters = arrayOf(InputFilter.LengthFilter(28))
            doAfterTextChanged { cfg.name = it?.toString() ?: ""; refresh() }
        }
        col.addView(nameEt, lp(top = 8))

        col.addView(tv("EXAM DATE", 12f, MUTED, true), lp(top = 20))
        dateBtn = Button(this).apply {
            isAllCaps = false; setTextColor(Color.WHITE); textSize = 16f
            background = round(CARD, 14)
            setOnClickListener {
                val d = LocalDate.ofEpochDay(cfg.examDay)
                val dlg = DatePickerDialog(this@MainActivity, { _, y, m, day ->
                    cfg.examDay = LocalDate.of(y, m + 1, day).toEpochDay()
                    cfg.startDay = -1
                    updateDate(); refresh()
                }, d.year, d.monthValue - 1, d.dayOfMonth)
                dlg.datePicker.minDate = System.currentTimeMillis() - 1000
                dlg.show()
            }
        }
        col.addView(dateBtn, lp(top = 8))

        col.addView(tv("THEME", 12f, MUTED, true), lp(top = 20))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        Themes.all.forEachIndexed { i, th ->
            val wrap = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(4), dp(4), dp(4), dp(8))
                setOnClickListener { cfg.theme = i; select() }
            }
            val iv = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                outlineProvider = ViewOutlineProvider.BACKGROUND
                background = round(Color.DKGRAY, 14); clipToOutline = true
            }
            wrap.addView(iv, LinearLayout.LayoutParams(dp(120), dp(260)))
            wrap.addView(tv(th.name, 13f, Color.WHITE).apply { setPadding(0, dp(6), 0, 0) })
            imgs.add(iv); wraps.add(wrap)
            row.addView(wrap, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(8) })
        }
        col.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) }, lp(top = 8))

        col.addView(tv("APPLY TO", 12f, MUTED, true), lp(top = 20))
        val rg = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        listOf("Home", "Lock", "Both").forEachIndexed { i, label ->
            rg.addView(RadioButton(this).apply {
                id = 100 + i; text = label; setTextColor(Color.WHITE)
                isChecked = (cfg.target == i)
            })
        }
        rg.setOnCheckedChangeListener { _, id -> cfg.target = id - 100 }
        col.addView(rg, lp(top = 8))

        val applyBtn = Button(this).apply {
            text = "Set wallpaper"; isAllCaps = false; textSize = 17f; setTextColor(Color.WHITE)
            background = round(ACC, 16)
            setOnClickListener {
                if (cfg.startDay < 0) cfg.startDay = LocalDate.now().toEpochDay()
                cfg.last = -1
                Prefs.save(this@MainActivity, cfg)
                Scheduler.schedule(this@MainActivity)
                isEnabled = false
                Thread {
                    val ok = try { Updater.apply(this@MainActivity, true) } catch (e: Exception) { false }
                    runOnUiThread {
                        isEnabled = true
                        Toast.makeText(this@MainActivity,
                            if (ok) "Wallpaper set. It will update daily." else "Could not set wallpaper.",
                            Toast.LENGTH_LONG).show()
                    }
                }.start()
            }
        }
        col.addView(applyBtn, lp(top = 24, h = dp(56)))
        setContentView(root)
        updateDate(); select()
    }

    private fun updateDate() {
        dateBtn.text = LocalDate.ofEpochDay(cfg.examDay)
            .format(DateTimeFormatter.ofPattern("EEEE, dd MMM yyyy", Locale.getDefault()))
    }

    private fun select() {
        wraps.forEachIndexed { i, w ->
            w.background = round(Color.TRANSPARENT, 18, dp(2), if (i == cfg.theme) ACC else Color.TRANSPARENT)
        }
        refresh()
    }

    private fun refresh() {
        val today = LocalDate.now().toEpochDay()
        imgs.forEachIndexed { i, iv -> iv.setImageBitmap(Updater.bitmapFor(cfg, i, 300, 650, today)) }
    }
}
