package com.examcountdown.wallpaper

import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.app.WallpaperManager
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputFilter
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.*
import androidx.core.content.FileProvider
import androidx.core.widget.doAfterTextChanged
import org.json.JSONObject
import java.io.File
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

class MainActivity : Activity() {
    private val BG = Color.parseColor("#0E0F14")
    private val CARD = Color.parseColor("#1A1C26")
    private val ACC = Color.parseColor("#7C5CFF")
    private val MUTED = Color.parseColor("#8B8FA3")

    private lateinit var cfg: Settings
    private var aspect = 2.1f
    private val handler = Handler(Looper.getMainLooper())

    private val imgs = ArrayList<ImageView>()
    private val wraps = ArrayList<LinearLayout>()
    private val dots = ArrayList<View>()
    private lateinit var dateBtn: Button
    private lateinit var startBtn: Button
    private lateinit var examList: LinearLayout
    private lateinit var btnThemes: Button
    private lateinit var btnPhoto: Button
    private lateinit var photoPanel: LinearLayout
    private lateinit var rowLabel: TextView
    private lateinit var row: LinearLayout
    private lateinit var widgetImg: ImageView
    private lateinit var calImg: ImageView
    private lateinit var listImg: ImageView
    private lateinit var prevPortrait: ImageView
    private lateinit var prevLand: ImageView
    private lateinit var statusText: TextView
    private lateinit var studyText: TextView
    private lateinit var timerText: TextView

    // ------------------------------------------------------------- small helpers
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun round(color: Int, r: Int, stroke: Int = 0, sc: Int = 0) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(r).toFloat(); if (stroke > 0) setStroke(stroke, sc)
    }
    private fun tv(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }
    private fun lp(top: Int = 0, h: Int = ViewGroup.LayoutParams.WRAP_CONTENT) =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h).apply { topMargin = dp(top) }
    private fun section(col: LinearLayout, t: String, top: Int = 20) { col.addView(tv(t, 12f, MUTED, true), lp(top = top)) }
    private fun note(col: LinearLayout, t: String) { col.addView(tv(t, 12f, MUTED).apply { setPadding(0, dp(6), 0, 0) }) }
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()
    private fun fmt(day: Long) = LocalDate.ofEpochDay(day)
        .format(DateTimeFormatter.ofPattern("EEE, dd MMM yyyy", Locale.getDefault()))

    private fun btn(label: String, outlined: Boolean = true, onClick: () -> Unit): Button = Button(this).apply {
        this.text = label; isAllCaps = false; textSize = 16f; setTextColor(Color.WHITE)
        background = if (outlined) round(CARD, 16, dp(1), ACC) else round(ACC, 16)
        setOnClickListener { onClick() }
    }

    private fun switchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit): Switch = Switch(this).apply {
        this.text = label; setTextColor(Color.WHITE); isChecked = checked
        setOnCheckedChangeListener { _, v -> onChange(v) }
    }

    private fun spinner(items: List<String>, selected: Int, onPick: (Int) -> Unit): Spinner {
        val sp = Spinner(this)
        val ad = ArrayAdapter(this, android.R.layout.simple_spinner_item, items)
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        sp.adapter = ad
        sp.setSelection(selected)
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                onPick(position)
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        return sp
    }

    private fun seekRow(label: String, maxV: Int, value: Int, onSet: (Int) -> Unit): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(12), 0, 0) }
        val t = tv("$label: $value", 13f, Color.WHITE)
        val sb = SeekBar(this).apply {
            max = maxV; progress = value
            progressTintList = ColorStateList.valueOf(ACC)
            thumbTintList = ColorStateList.valueOf(ACC)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, p: Int, fromUser: Boolean) {
                    t.text = "$label: $p"; onSet(p)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) { refresh() }
            })
        }
        box.addView(t); box.addView(sb)
        return box
    }

    private fun radios(base: Int, labels: List<String>, selected: Int, onPick: (Int) -> Unit): RadioGroup {
        val g = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        labels.forEachIndexed { i, l ->
            g.addView(RadioButton(this).apply {
                id = base + i; text = l; setTextColor(Color.WHITE); isChecked = (i == selected)
            })
        }
        g.setOnCheckedChangeListener { _, id -> onPick(id - base); refresh() }
        return g
    }

    private fun curMode() = cfg.mode
    private fun selIndex() = if (cfg.mode == 1) cfg.style else cfg.theme
    private fun setSel(i: Int) { if (cfg.mode == 1) cfg.style = i else cfg.theme = i }

    private fun commit() {
        if (cfg.startDay < 0) cfg.startDay = LocalDate.now().toEpochDay()
        Prefs.save(this, cfg)
    }

    // ------------------------------------------------------------------- create
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        cfg = Prefs.load(this)
        val today = LocalDate.now().toEpochDay()
        if (cfg.examDay < 0) cfg.examDay = today + 60
        val sz = Screen.size(this)
        aspect = sz.second.toFloat() / sz.first.toFloat()
        window.statusBarColor = BG; window.navigationBarColor = BG

        val root = ScrollView(this).apply { setBackgroundColor(BG) }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(48), dp(20), dp(32))
        }
        root.addView(col)
        col.addView(tv("Exam Countdown", 30f, Color.WHITE, true))
        col.addView(tv("Wallpaper, widgets, reminders and study tools.", 14f, MUTED).apply {
            setPadding(0, dp(4), 0, dp(24))
        })

        buildPreviewSection(col)
        buildExamSection(col)
        buildBackgroundSection(col)
        buildTextSection(col)
        buildQuoteSection(col)
        buildNotifySection(col)
        buildWidgetSection(col)
        buildStudySection(col)
        buildToolsSection(col)

        setContentView(root)
        updateDate()
        rebuildExamList()
        buildPhotoPanel()
        applyUiMode()
        Scheduler.schedule(this)
        maybeShowGuide()
    }

    override fun onResume() { super.onResume(); updateStatus(); handler.post(ticker) }
    override fun onPause() { super.onPause(); handler.removeCallbacks(ticker) }

    private val ticker = object : Runnable {
        override fun run() { updateStudy(); handler.postDelayed(this, 1000) }
    }

    // ------------------------------------------------------------ exam section
    private fun buildExamSection(col: LinearLayout) {
        col.addView(tv("EXAM NAME", 12f, MUTED, true))
        val nameEt = EditText(this).apply {
            setText(cfg.name); hint = "e.g. Board Exams"
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            background = round(CARD, 14); setPadding(dp(16), dp(14), dp(16), dp(14))
            setSingleLine(); filters = arrayOf(InputFilter.LengthFilter(28))
            doAfterTextChanged { cfg.name = it?.toString() ?: ""; refresh() }
        }
        col.addView(nameEt, lp(top = 8))

        section(col, "EXAM DATE")
        dateBtn = Button(this).apply {
            isAllCaps = false; setTextColor(Color.WHITE); textSize = 16f
            background = round(CARD, 14)
            setOnClickListener {
                val d = LocalDate.ofEpochDay(cfg.examDay)
                val dlg = DatePickerDialog(this@MainActivity, { _, y, m, day ->
                    cfg.examDay = LocalDate.of(y, m + 1, day).toEpochDay()
                    if (!cfg.startSet || cfg.startDay >= cfg.examDay) { cfg.startDay = -1; cfg.startSet = false }
                    updateDate(); refresh()
                }, d.year, d.monthValue - 1, d.dayOfMonth)
                dlg.datePicker.minDate = System.currentTimeMillis() - 1000
                dlg.show()
            }
        }
        col.addView(dateBtn, lp(top = 8))

        section(col, "COUNTDOWN STARTS ON")
        val startRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        startBtn = Button(this).apply {
            isAllCaps = false; setTextColor(Color.WHITE); textSize = 16f
            background = round(CARD, 14)
            setOnClickListener {
                val cur = if (cfg.startDay >= 0) LocalDate.ofEpochDay(cfg.startDay) else LocalDate.now()
                val dlg = DatePickerDialog(this@MainActivity, { _, y, m, day ->
                    val picked = LocalDate.of(y, m + 1, day).toEpochDay()
                    if (picked >= cfg.examDay) toast("Start date must be before the exam date.")
                    else { cfg.startDay = picked; cfg.startSet = true; updateDate(); refresh() }
                }, cur.year, cur.monthValue - 1, cur.dayOfMonth)
                dlg.datePicker.maxDate = System.currentTimeMillis()
                dlg.datePicker.minDate = System.currentTimeMillis() - 730L * 24L * 3600L * 1000L
                dlg.show()
            }
        }
        val resetStart = Button(this).apply {
            text = "Today"; isAllCaps = false; setTextColor(Color.WHITE)
            background = round(CARD, 14)
            setOnClickListener { cfg.startDay = -1; cfg.startSet = false; updateDate(); refresh() }
        }
        startRow.addView(startBtn, LinearLayout.LayoutParams(0, dp(48), 1f).apply { rightMargin = dp(8) })
        startRow.addView(resetStart, LinearLayout.LayoutParams(dp(84), dp(48)))
        col.addView(startRow, lp(top = 8))
        note(col, "The progress ring is full on this day and shrinks until the exam.")

        section(col, "MORE EXAMS")
        examList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(examList, lp())
        col.addView(btn("Add another exam") { addExamDialog() }, lp(top = 10, h = dp(48)))
        note(col, "The wallpaper and widgets automatically switch to whichever exam is next.")
    }

    private fun rebuildExamList() {
        examList.removeAllViews()
        cfg.extra.forEachIndexed { i, ex ->
            val r = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                background = round(CARD, 12); setPadding(dp(14), dp(8), dp(8), dp(8))
            }
            r.addView(tv(ex.name + "\n" + fmt(ex.day), 14f, Color.WHITE),
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val del = Button(this).apply {
                text = "Remove"; isAllCaps = false; textSize = 12f; setTextColor(Color.WHITE)
                background = round(Color.parseColor("#3A1F2B"), 10)
                setOnClickListener {
                    cfg.extra = cfg.extra.filterIndexed { j, _ -> j != i }
                    rebuildExamList(); refresh()
                }
            }
            r.addView(del, LinearLayout.LayoutParams(dp(90), dp(40)))
            examList.addView(r, lp(top = 8))
        }
    }

    private fun addExamDialog() {
        val et = EditText(this).apply {
            hint = "Exam name, e.g. Physics"; setSingleLine(); filters = arrayOf(InputFilter.LengthFilter(28))
        }
        AlertDialog.Builder(this).setTitle("Add exam").setView(et)
            .setPositiveButton("Pick date") { _, _ ->
                val nm = et.text.toString().trim().ifEmpty { "Exam" }
                val d = LocalDate.now().plusDays(30)
                val dlg = DatePickerDialog(this, { _, y, m, day ->
                    val dd = LocalDate.of(y, m + 1, day).toEpochDay()
                    cfg.extra = cfg.extra + Exam(nm, dd, LocalDate.now().toEpochDay())
                    rebuildExamList(); refresh()
                }, d.year, d.monthValue - 1, d.dayOfMonth)
                dlg.datePicker.minDate = System.currentTimeMillis() - 1000
                dlg.show()
            }
            .setNegativeButton("Cancel", null).show()
    }

    // ------------------------------------------------------- background section
    private fun buildBackgroundSection(col: LinearLayout) {
        section(col, "BACKGROUND")
        val seg = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        btnThemes = Button(this).apply {
            text = "Gradient themes"; isAllCaps = false; setTextColor(Color.WHITE)
            setOnClickListener { setCurMode(0) }
        }
        btnPhoto = Button(this).apply {
            text = "My photo"; isAllCaps = false; setTextColor(Color.WHITE)
            setOnClickListener { setCurMode(1) }
        }
        seg.addView(btnThemes, LinearLayout.LayoutParams(0, dp(48), 1f).apply { rightMargin = dp(8) })
        seg.addView(btnPhoto, LinearLayout.LayoutParams(0, dp(48), 1f))
        col.addView(seg, lp(top = 8))

        photoPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        col.addView(photoPanel, lp())

        rowLabel = tv("THEME  (swipe for more)", 12f, MUTED, true)
        col.addView(rowLabel, lp(top = 20))
        row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        col.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) }, lp(top = 8))
    }

    private fun setCurMode(m: Int) {
        cfg.mode = m
        applyUiMode()
    }

    private fun applyUiMode() {
        val m = curMode()
        photoPanel.visibility = if (m == 1) View.VISIBLE else View.GONE
        btnThemes.background = round(if (m == 0) ACC else CARD, 14)
        btnPhoto.background = round(if (m == 1) ACC else CARD, 14)
        buildCards()
        select()
    }

    private fun buildPhotoPanel() {
        photoPanel.removeAllViews(); dots.clear()
        val n = PhotoStore.count(this)
        photoPanel.addView(btn(if (n == 0) "Choose a photo" else "Add another photo") { pickPhoto() },
            lp(top = 14, h = dp(52)))
        photoPanel.addView(tv("Photos stay on your phone. Tap one to use it, long-press to delete. " +
            "Up to " + PhotoStore.MAX_PHOTOS + ".", 12f, MUTED).apply { setPadding(0, dp(6), 0, 0) })
        if (n > 0) {
            val strip = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (i in 0 until n) {
                val iv = ImageView(this).apply {
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    outlineProvider = ViewOutlineProvider.BACKGROUND
                    background = round(Color.DKGRAY, 10); clipToOutline = true
                    setImageBitmap(PhotoStore.thumb(this@MainActivity, i))
                    setOnClickListener { cfg.photoSel = i; photoPanel.post { buildPhotoPanel(); refresh() } }
                    setOnLongClickListener { confirmDelete(i); true }
                }
                val border = FrameLayout(this).apply {
                    setPadding(dp(3), dp(3), dp(3), dp(3))
                    background = round(Color.TRANSPARENT, 12, dp(2),
                        if (i == cfg.photoSel.coerceIn(0, n - 1) && !cfg.slideshow) ACC else Color.TRANSPARENT)
                }
                border.addView(iv, FrameLayout.LayoutParams(dp(64), dp(64)))
                strip.addView(border, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(8) })
            }
            photoPanel.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(strip) },
                lp(top = 10))
            photoPanel.addView(switchRow("Change photo every day (slideshow)", cfg.slideshow) {
                cfg.slideshow = it; photoPanel.post { buildPhotoPanel(); refresh() }
            }, lp(top = 10))
        }
        photoPanel.addView(seekRow("Darken", 70, cfg.dim) { cfg.dim = it })
        photoPanel.addView(seekRow("Blur", 20, cfg.blur) { cfg.blur = it })
        photoPanel.addView(seekRow("Move photo left / right", 100, cfg.fx) { cfg.fx = it })
        photoPanel.addView(seekRow("Move photo up / down", 100, cfg.fy) { cfg.fy = it })

        photoPanel.addView(tv("OVERLAY POSITION", 12f, MUTED, true), lp(top = 18))
        photoPanel.addView(radios(200, listOf("Top", "Middle", "Bottom"), cfg.pos) { cfg.pos = it }, lp(top = 6))
        photoPanel.addView(tv("TEXT COLOUR", 12f, MUTED, true), lp(top = 14))
        photoPanel.addView(radios(300, listOf("Auto", "Light", "Dark"), cfg.ink) { cfg.ink = it }, lp(top = 6))
        photoPanel.addView(tv("ACCENT COLOUR", 12f, MUTED, true), lp(top = 14))
        val sw = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        Accents.list.forEachIndexed { i, _ ->
            val v = View(this)
            v.setOnClickListener { cfg.acc = i; paintDots(); refresh() }
            dots.add(v)
            sw.addView(v, LinearLayout.LayoutParams(dp(34), dp(34)).apply { rightMargin = dp(10) })
        }
        photoPanel.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(sw) }, lp(top = 8))
        paintDots()
    }

    private fun confirmDelete(i: Int) {
        AlertDialog.Builder(this).setTitle("Delete this photo?")
            .setPositiveButton("Delete") { _, _ ->
                PhotoStore.remove(this, i)
                cfg.photoSel = 0
                buildPhotoPanel(); refresh()
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun paintDots() {
        dots.forEachIndexed { i, v ->
            v.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Accents.list[i])
                setStroke(dp(if (i == cfg.acc) 3 else 1),
                    if (i == cfg.acc) ACC else Color.parseColor("#55FFFFFF"))
            }
        }
    }

    private fun buildCards() {
        row.removeAllViews(); imgs.clear(); wraps.clear()
        val names = if (curMode() == 1) PhotoRenderer.styleNames else Themes.all.map { it.name }
        rowLabel.text = (if (curMode() == 1) "OVERLAY STYLE" else "THEME") + "  (swipe for more)"
        val cardW = if (resources.configuration.smallestScreenWidthDp >= 600) dp(150) else dp(112)
        val cardH = (cardW * aspect).toInt()
        names.forEachIndexed { i, nm ->
            val wrap = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(4), dp(4), dp(4), dp(8))
                setOnClickListener { setSel(i); select() }
            }
            val iv = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                outlineProvider = ViewOutlineProvider.BACKGROUND
                background = round(Color.DKGRAY, 14); clipToOutline = true
            }
            wrap.addView(iv, LinearLayout.LayoutParams(cardW, cardH))
            wrap.addView(tv(nm, 12f, Color.WHITE).apply { setPadding(0, dp(6), 0, 0) })
            imgs.add(iv); wraps.add(wrap)
            row.addView(wrap, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(8) })
        }
    }

    private fun select() {
        wraps.forEachIndexed { i, w ->
            w.background = round(Color.TRANSPARENT, 18, dp(2), if (i == selIndex()) ACC else Color.TRANSPARENT)
        }
        refresh()
    }

    // ------------------------------------------------------------ text section
    private fun buildTextSection(col: LinearLayout) {
        section(col, "NUMBER STYLE")
        col.addView(spinner(Fonts.names, cfg.font) { cfg.font = it; refresh() }, lp(top = 6))
        col.addView(switchRow("Urgency colours (green → amber → red)", cfg.urgency) { cfg.urgency = it; refresh() },
            lp(top = 12))
        section(col, "COUNT IN", 16)
        col.addView(radios(400, listOf("Days", "Weeks", "Hours"), cfg.unit) { cfg.unit = it }, lp(top = 6))
        section(col, "SKIP DAYS (study days only)", 14)
        col.addView(radios(500, listOf("None", "Sundays", "Sat + Sun"), cfg.skip) { cfg.skip = it }, lp(top = 6))
        note(col, "Skipping days applies to the Days view. Hours update every few hours.")
    }

    private fun buildQuoteSection(col: LinearLayout) {
        section(col, "DAILY QUOTE")
        col.addView(switchRow("Show a quote or message", cfg.quote) { cfg.quote = it; refresh() }, lp(top = 8))
        col.addView(spinner(Quotes.categories, cfg.qcat) { cfg.qcat = it; refresh() }, lp(top = 8))
        val et = EditText(this).apply {
            setText(cfg.custom); hint = "Your own message (replaces the daily quote)"
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            background = round(CARD, 14); setPadding(dp(16), dp(12), dp(16), dp(12))
            filters = arrayOf(InputFilter.LengthFilter(90))
            doAfterTextChanged { cfg.custom = it?.toString() ?: ""; refresh() }
        }
        col.addView(et, lp(top = 8))
    }

    // ------------------------------------------------------ reminders section
    private fun requestNotifPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 7)
        }
    }

    private fun buildNotifySection(col: LinearLayout) {
        section(col, "REMINDERS")
        col.addView(radios(600, listOf("Off", "Milestones", "Every day"), cfg.notify) {
            cfg.notify = it
            if (it > 0) requestNotifPermission()
            Scheduler.schedule(this)
        }, lp(top = 6))
        col.addView(seekRow("Send at hour (24h)", 23, cfg.notifyHour) { cfg.notifyHour = it })
        note(col, "Milestones: 100, 50, 30, 14, 7, 3, 2, 1 days and exam day. Each reminder includes your quote.")
    }

    // ------------------------------------------------------ preview + apply
    private fun buildPreviewSection(col: LinearLayout) {
        val sz = Screen.size(this)
        col.addView(tv("YOUR SCREEN  " + sz.first + " × " + sz.second + " px", 12f, MUTED, true))
        statusText = tv("", 13f, Color.WHITE)
        col.addView(statusText, lp(top = 6))
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        }
        prevPortrait = ImageView(this).apply {
            adjustViewBounds = true
            outlineProvider = ViewOutlineProvider.BACKGROUND
            background = round(Color.DKGRAY, 18); clipToOutline = true
        }
        prevLand = ImageView(this).apply {
            adjustViewBounds = true
            outlineProvider = ViewOutlineProvider.BACKGROUND
            background = round(Color.DKGRAY, 14); clipToOutline = true
        }
        box.addView(prevPortrait, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.42f)
            .apply { rightMargin = dp(12) })
        box.addView(prevLand, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.58f))
        col.addView(box, lp(top = 10))
        note(col, "Previews use your device's real screen shape. The wallpaper is drawn at the exact size of " +
            "your screen and redraws itself when you rotate, so nothing is cropped or stretched.")
        val applyBtn = btn("Apply wallpaper", false) { applyWallpaper() }
        applyBtn.textSize = 17f
        col.addView(applyBtn, lp(top = 14, h = dp(56)))
        col.addView(spacer(8))
    }

    private fun spacer(h: Int) = View(this).apply { minimumHeight = dp(h) }

    private fun updateStatus() {
        if (!::statusText.isInitialized) return
        statusText.text = if (Updater.isLiveActive(this)) "●  Adaptive wallpaper is active"
        else "○  Not applied yet. Tap Apply wallpaper."
    }

    private fun applyWallpaper() {
        if (Updater.usesPhoto(cfg) && !PhotoStore.exists(this)) {
            toast("Choose a photo first.")
            return
        }
        commit()
        Scheduler.schedule(this)
        if (Updater.isLiveActive(this)) {
            Updater.refreshWidgets(this)
            toast("Wallpaper updated.")
            updateStatus()
        } else {
            launchLive()
        }
    }

    private fun launchLive() {
        val comp = ComponentName(this, CountdownWallpaperService::class.java)
        try {
            startActivity(Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
                .putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, comp))
        } catch (e: Exception) {
            try {
                startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
            } catch (e2: Exception) {
                toast("Live wallpapers are not supported on this phone.")
            }
        }
    }

    // ---------------------------------------------------------- widget section
    private fun preview(): ImageView = ImageView(this).apply { adjustViewBounds = true }

    private fun pin(cls: Class<*>) {
        commit()
        val mgr = AppWidgetManager.getInstance(this)
        if (mgr.isRequestPinAppWidgetSupported) {
            mgr.requestPinAppWidget(ComponentName(this, cls), null, null)
        } else {
            toast("Long-press your home screen, tap Widgets, then pick Exam Countdown.")
        }
    }

    private fun buildWidgetSection(col: LinearLayout) {
        section(col, "WIDGETS", 28)
        widgetImg = preview(); calImg = preview(); listImg = preview()
        col.addView(tv("Countdown (resizable, wide size shows the quote)", 12f, Color.WHITE), lp(top = 8))
        col.addView(widgetImg, lp(top = 6))
        col.addView(btn("Add countdown widget") { pin(CountdownWidget::class.java) }, lp(top = 8, h = dp(48)))
        col.addView(tv("Calendar (crosses off each day)", 12f, Color.WHITE), lp(top = 18))
        col.addView(calImg, lp(top = 6))
        col.addView(btn("Add calendar widget") { pin(CalendarWidget::class.java) }, lp(top = 8, h = dp(48)))
        col.addView(tv("All exams (next four)", 12f, Color.WHITE), lp(top = 18))
        col.addView(listImg, lp(top = 6))
        col.addView(btn("Add exam list widget") { pin(ListWidget::class.java) }, lp(top = 8, h = dp(48)))
        col.addView(btn("Add tiny 1×1 widget") { pin(TinyWidget::class.java) }, lp(top = 14, h = dp(48)))
    }

    // ----------------------------------------------------------- study section
    private fun buildStudySection(col: LinearLayout) {
        section(col, "STUDY TOOLS", 28)
        studyText = tv("", 14f, Color.WHITE)
        col.addView(studyText, lp(top = 8))
        timerText = tv("Timer ready", 22f, Color.WHITE, true)
        col.addView(timerText, lp(top = 10))
        val timers = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun small(t: String, on: () -> Unit) = btn(t) { on() }.apply { textSize = 14f }
        timers.addView(small("Focus 25") { requestNotifPermission(); Study.start(this, 25, true); updateStudy() },
            LinearLayout.LayoutParams(0, dp(48), 1f).apply { rightMargin = dp(6) })
        timers.addView(small("Break 5") { Study.start(this, 5, false); updateStudy() },
            LinearLayout.LayoutParams(0, dp(48), 1f).apply { rightMargin = dp(6) })
        timers.addView(small("Stop") { Study.cancel(this); updateStudy() },
            LinearLayout.LayoutParams(0, dp(48), 1f))
        col.addView(timers, lp(top = 8))
        val logs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val today = { LocalDate.now().toEpochDay() }
        logs.addView(small("+15 min") { Study.add(this, today(), 15); updateStudy() },
            LinearLayout.LayoutParams(0, dp(48), 1f).apply { rightMargin = dp(6) })
        logs.addView(small("+30 min") { Study.add(this, today(), 30); updateStudy() },
            LinearLayout.LayoutParams(0, dp(48), 1f).apply { rightMargin = dp(6) })
        logs.addView(small("Reset today") { Study.resetDay(this, today()); updateStudy() },
            LinearLayout.LayoutParams(0, dp(48), 1f))
        col.addView(logs, lp(top = 8))
        col.addView(seekRow("Daily study goal (hours)", 10, cfg.goalHours) { cfg.goalHours = maxOf(1, it) })
        note(col, "A finished focus session adds its minutes automatically. Reach your goal on consecutive days to build a streak.")
    }

    private fun updateStudy() {
        if (!::studyText.isInitialized || !::timerText.isInitialized) return
        val done = Study.completeIfDue(this)
        if (done != null) toast(if (done.first) "Focus session complete! " + done.second + " min added." else "Break over.")
        val rem = Study.remainingMs(this)
        timerText.text = if (rem < 0) "Timer ready" else
            (if (Study.isFocus(this)) "Focus  " else "Break  ") +
                String.format(Locale.US, "%02d:%02d", rem / 60000, (rem / 1000) % 60)
        val today = LocalDate.now().toEpochDay()
        val goal = cfg.goalHours * 60
        studyText.text = "Today: " + Study.minutes(this, today) + " / " + goal + " min     Streak: " +
            Study.streak(this, goal, today) + " days"
    }

    // ----------------------------------------------------------- tools section
    private fun buildToolsSection(col: LinearLayout) {
        section(col, "SHARE & BACKUP", 28)
        col.addView(btn("Share countdown image") { shareImage() }, lp(top = 8, h = dp(48)))
        col.addView(btn("Save image to phone") {
            startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "image/png"; putExtra(Intent.EXTRA_TITLE, "exam-countdown.png")
            }, 51)
        }, lp(top = 10, h = dp(48)))
        col.addView(btn("Export settings backup") {
            startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"
                putExtra(Intent.EXTRA_TITLE, "exam-countdown-backup.json")
            }, 52)
        }, lp(top = 10, h = dp(48)))
        col.addView(btn("Restore settings backup") {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
            }, 53)
        }, lp(top = 10, h = dp(48)))
        note(col, "Backups include settings and exams, not your photos.")
        col.addView(btn("Show quick guide") { showGuide() }, lp(top = 14, h = dp(48)))
    }

    private fun shareImage() {
        toast("Preparing image...")
        Thread {
            try {
                val today = LocalDate.now().toEpochDay()
                val bmp = Updater.wallpaperBitmap(this, cfg, 1080, 1920, today, false)
                val dir = File(cacheDir, "shared")
                dir.mkdirs()
                val f = File(dir, "exam-countdown.png")
                f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                bmp.recycle()
                val uri = FileProvider.getUriForFile(this, "$packageName.files", f)
                runOnUiThread {
                    val i = Intent(Intent.ACTION_SEND).apply {
                        type = "image/png"; putExtra(Intent.EXTRA_STREAM, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    startActivity(Intent.createChooser(i, "Share countdown"))
                }
            } catch (e: Exception) {
                runOnUiThread { toast("Could not create the image.") }
            }
        }.start()
    }

    // ------------------------------------------------------------ guide / perms
    private fun maybeShowGuide() {
        val sp = getSharedPreferences("app", MODE_PRIVATE)
        if (!sp.getBoolean("guide_shown", false)) {
            sp.edit().putBoolean("guide_shown", true).apply()
            showGuide()
        }
    }

    private fun showGuide() {
        AlertDialog.Builder(this).setTitle("Quick setup")
            .setMessage("1. Enter your exam, then choose a theme or your own photo.\n" +
                "2. Tap Apply wallpaper, then Set wallpaper on the Android screen.\n" +
                "3. It rotates with your screen and updates itself every day.\n" +
                "4. Add widgets from the Widgets section.\n" +
                "5. Allow notifications for reminders and set battery use to Unrestricted.")
            .setPositiveButton("Got it", null)
            .setNeutralButton("Allow notifications") { _, _ -> requestNotifPermission() }
            .setNegativeButton("Battery settings") { _, _ -> openBattery() }
            .show()
    }

    private fun openBattery() {
        try {
            startActivity(Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        } catch (e: Exception) {
            try {
                startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:$packageName")))
            } catch (e2: Exception) { }
        }
    }

    // ---------------------------------------------------------------- results
    private fun pickPhoto() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "image/*"
        }
        try { startActivityForResult(i, 42) } catch (e: Exception) { toast("No photo picker found on this phone.") }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        when (requestCode) {
            42 -> {
                if (PhotoStore.count(this) >= PhotoStore.MAX_PHOTOS) { toast("Photo limit reached. Delete one first."); return }
                toast("Loading photo...")
                Thread {
                    val ok = PhotoStore.import(this, uri)
                    runOnUiThread {
                        if (ok) {
                            cfg.photoSel = PhotoStore.newestIndex(this)
                            cfg.fx = 50; cfg.fy = 50
                            cfg.mode = 1
                            buildPhotoPanel()
                            applyUiMode()
                        } else toast("Could not read that photo.")
                    }
                }.start()
            }
            51 -> Thread {
                try {
                    val bmp = Updater.wallpaperBitmap(this, cfg, 1080, 1920, LocalDate.now().toEpochDay(), false)
                    contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                    bmp.recycle()
                    runOnUiThread { toast("Image saved.") }
                } catch (e: Exception) { runOnUiThread { toast("Could not save the image.") } }
            }.start()
            52 -> {
                try {
                    contentResolver.openOutputStream(uri)?.use { it.write(Prefs.toJson(cfg).toString(2).toByteArray()) }
                    toast("Backup saved.")
                } catch (e: Exception) { toast("Could not save the backup.") }
            }
            53 -> {
                try {
                    val text = contentResolver.openInputStream(uri)?.use { String(it.readBytes()) } ?: ""
                    val restored = Prefs.fromJson(JSONObject(text))
                    Prefs.save(this, restored)
                    toast("Settings restored.")
                    recreate()
                } catch (e: Exception) { toast("That file is not a valid backup.") }
            }
        }
    }

    // ---------------------------------------------------------------- refresh
    private fun updateDate() {
        dateBtn.text = fmt(cfg.examDay)
        startBtn.text = if (cfg.startSet && cfg.startDay >= 0) fmt(cfg.startDay) else "Today (automatic)"
    }

    private fun refresh() {
        if (!::widgetImg.isInitialized || !::calImg.isInitialized || !::listImg.isInitialized ||
            !::prevPortrait.isInitialized || !::prevLand.isInitialized || imgs.isEmpty()) return
        Prefs.save(this, cfg)
        val today = LocalDate.now().toEpochDay()
        val pw = 240
        val ph = (pw * aspect).toInt()
        val m = curMode()
        imgs.forEachIndexed { i, iv -> iv.setImageBitmap(Updater.bitmapFor(this, cfg, m, i, pw, ph, today, true)) }
        // Big previews keep the exact shape of this device (portrait and rotated).
        prevPortrait.setImageBitmap(Updater.bitmapFor(this, cfg, m, selIndex(), 420, (420 * aspect).toInt(), today, true))
        prevLand.setImageBitmap(Updater.bitmapFor(this, cfg, m, selIndex(), 640, (640 / aspect).toInt(), today, true))
        widgetImg.setImageBitmap(Updater.widgetBitmap(this, cfg, 0, 640, 300, today, true, true))
        calImg.setImageBitmap(Updater.widgetBitmap(this, cfg, 2, 640, 300, today, false, true))
        listImg.setImageBitmap(Updater.widgetBitmap(this, cfg, 3, 640, 300, today, false, true))
    }
}
