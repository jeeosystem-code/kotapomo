package com.examcountdown.wallpaper

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.Canvas
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import androidx.core.content.ContextCompat
import java.time.LocalDate
import java.time.LocalDateTime

/**
 * Adaptive wallpaper: redraws at the real surface size, so portrait, landscape,
 * tablets and foldables always get a correctly laid-out countdown.
 */
class CountdownWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = CountdownEngine()

    inner class CountdownEngine : Engine() {
        private var w = 0
        private var h = 0
        private val cache = HashMap<String, Bitmap>()
        @Volatile private var warming = false

        private val clock = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) { drawFrame() }
        }

        override fun onCreate(surfaceHolder: SurfaceHolder?) {
            super.onCreate(surfaceHolder)
            val f = IntentFilter().apply {
                addAction(Intent.ACTION_DATE_CHANGED)
                addAction(Intent.ACTION_TIME_CHANGED)
                addAction(Intent.ACTION_TIMEZONE_CHANGED)
            }
            try {
                ContextCompat.registerReceiver(this@CountdownWallpaperService, clock, f,
                    ContextCompat.RECEIVER_NOT_EXPORTED)
            } catch (e: Exception) { }
        }

        override fun onDestroy() {
            try { unregisterReceiver(clock) } catch (e: Exception) { }
            synchronized(cache) { cache.clear() }
            super.onDestroy()
        }

        override fun onSurfaceChanged(holder: SurfaceHolder?, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            w = width; h = height
            drawFrame()
        }

        override fun onSurfaceRedrawNeeded(holder: SurfaceHolder?) {
            super.onSurfaceRedrawNeeded(holder)
            drawFrame()
        }

        override fun onVisibilityChanged(visible: Boolean) {
            super.onVisibilityChanged(visible)
            if (visible) drawFrame()
        }

        private fun keyFor(s: Settings, today: Long, bw: Int, bh: Int) =
            "$bw x $bh|$today|${if (s.unit == 2) LocalDateTime.now().hour else 0}|${s.hashCode()}"

        private fun build(s: Settings, today: Long, bw: Int, bh: Int): Bitmap {
            val key = keyFor(s, today, bw, bh)
            synchronized(cache) { cache[key]?.let { return it } }
            val b = Updater.wallpaperBitmap(applicationContext, s, bw, bh, today, false)
            synchronized(cache) {
                if (cache.size >= 3) cache.clear()
                cache[key] = b
            }
            return b
        }

        private fun drawFrame() {
            if (w <= 0 || h <= 0) return
            val today = LocalDate.now().toEpochDay()
            var s = Prefs.load(applicationContext)
            if (s.examDay < 0 && s.extra.isEmpty()) s = s.copy(examDay = today + 30, name = "Open Exam Countdown")
            val bmp = try { build(s, today, w, h) } catch (e: Exception) { return }
            var canvas: Canvas? = null
            try {
                canvas = surfaceHolder.lockCanvas()
                if (canvas != null) canvas.drawBitmap(bmp, 0f, 0f, null)
            } catch (e: Exception) {
            } finally {
                if (canvas != null) {
                    try { surfaceHolder.unlockCanvasAndPost(canvas) } catch (e: Exception) { }
                }
            }
            warmOtherOrientation(s, today)
        }

        /** Prepares the rotated version in the background so rotating is instant. */
        private fun warmOtherOrientation(s: Settings, today: Long) {
            if (warming) return
            val ow = h; val oh = w
            synchronized(cache) { if (cache.containsKey(keyFor(s, today, ow, oh))) return }
            warming = true
            Thread {
                try { build(s, today, ow, oh) } catch (e: Exception) { } finally { warming = false }
            }.start()
        }
    }
}
