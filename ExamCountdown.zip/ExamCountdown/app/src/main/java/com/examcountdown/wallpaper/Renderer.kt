package com.examcountdown.wallpaper

import android.graphics.*

data class Blob(val x: Float, val y: Float, val r: Float, val color: Int)

data class Theme(
    val name: String, val top: Int, val bottom: Int, val text: Int, val sub: Int,
    val accent: Int, val track: Int, val font: Typeface, val deco: Int,
    val blobs: List<Blob> = emptyList(), val layout: Int = 0, val glass: Int = 0x26FFFFFF
)

object Themes {
    private fun c(s: String) = Color.parseColor(s)
    private fun b(x: Float, y: Float, r: Float, s: String) = Blob(x, y, r, Color.parseColor(s))
    private val thin = Typeface.create("sans-serif-thin", Typeface.NORMAL)
    private val light = Typeface.create("sans-serif-light", Typeface.NORMAL)
    val all = listOf(
        Theme("Cotton Candy", c("#FFD9EC"), c("#D9E6FF"), c("#3A2E5C"), c("#7A6E9B"), c("#5B4B9A"), c("#26000000"),
            light, -1, listOf(b(0.12f, 0.18f, 0.75f, "#E6FF8FC8"), b(0.95f, 0.32f, 0.70f, "#D9B3A0FF"),
                b(0.15f, 0.88f, 0.85f, "#D9FFC9A3"), b(0.88f, 0.92f, 0.65f, "#CC9ED2FF")), 1, c("#59FFFFFF")),
        Theme("Ocean Glass", c("#031B34"), c("#0A4D68"), c("#FFFFFF"), c("#BFEFF5"), c("#7DF9FF"), c("#33FFFFFF"),
            thin, -1, listOf(b(0.10f, 0.15f, 0.80f, "#CC00D2C6"), b(0.95f, 0.45f, 0.75f, "#B31E6BFF"),
                b(0.20f, 0.95f, 0.85f, "#B30A8FB5"), b(0.85f, 0.05f, 0.50f, "#667DF9FF")), 1),
        Theme("Peach Fizz", c("#FF9A8B"), c("#FF6A88"), c("#FFFFFF"), c("#FFF0E8"), c("#FFFFFF"), c("#44FFFFFF"),
            thin, -1, listOf(b(0.85f, 0.12f, 0.70f, "#E6FFD27D"), b(0.05f, 0.45f, 0.70f, "#CCFF4F9A"),
                b(0.90f, 0.75f, 0.75f, "#CCFF8F5A"), b(0.25f, 0.98f, 0.70f, "#B3FFE0C2")), 1),
        Theme("Midnight Mesh", c("#0A0A1F"), c("#1A0B33"), c("#FFFFFF"), c("#B7B4E6"), c("#C7B8FF"), c("#33FFFFFF"),
            thin, -1, listOf(b(0.15f, 0.20f, 0.85f, "#CC4F46E5"), b(0.95f, 0.50f, 0.75f, "#B3D946EF"),
                b(0.10f, 0.90f, 0.80f, "#B3312E81"), b(0.80f, 0.95f, 0.45f, "#6622D3EE")), 1),
        Theme("Lavender Haze", c("#EBDCFF"), c("#C9BBFF"), c("#2E1065"), c("#6B5BA8"), c("#4C2D9E"), c("#26000000"),
            light, -1, listOf(b(0.10f, 0.12f, 0.75f, "#D9A78BFA"), b(0.92f, 0.35f, 0.70f, "#CCF0ABFC"),
                b(0.15f, 0.80f, 0.80f, "#CC93C5FD"), b(0.85f, 0.95f, 0.60f, "#B3FDE68A")), 1, c("#59FFFFFF")),
        Theme("Mint Dew", c("#D9FBEA"), c("#A9F2D2"), c("#064E3B"), c("#3F8A72"), c("#0B7A5A"), c("#26000000"),
            light, -1, listOf(b(0.90f, 0.12f, 0.75f, "#CC6EE7B7"), b(0.05f, 0.40f, 0.70f, "#B35EEAD4"),
                b(0.85f, 0.85f, 0.80f, "#B3BEF264"), b(0.15f, 0.97f, 0.65f, "#B37DD3FC")), 1, c("#59FFFFFF")),
        Theme("Aurora", c("#0B1030"), c("#3B1C6B"), c("#FFFFFF"), c("#B9B4E8"), c("#7CF0D4"), c("#33FFFFFF"),
            Typeface.create("sans-serif-thin", Typeface.NORMAL), 0),
        Theme("Sunset", c("#FF9966"), c("#FF5E62"), c("#FFFFFF"), c("#FFF1E0"), c("#FFF1C1"), c("#44FFFFFF"),
            Typeface.create("sans-serif-condensed", Typeface.BOLD), 1),
        Theme("Paper", c("#F7F3EA"), c("#E9E2D0"), c("#1B1B1B"), c("#6B6458"), c("#D9482B"), c("#22000000"),
            Typeface.create("serif", Typeface.NORMAL), 2),
        Theme("Neon", c("#05060A"), c("#150028"), c("#F5F5FF"), c("#8A8FFF"), c("#00E5FF"), c("#3300E5FF"),
            Typeface.create("monospace", Typeface.BOLD), 3),
        Theme("Forest", c("#0F2E22"), c("#2E6B4F"), c("#F2FFF6"), c("#A8D8BC"), c("#FFD479"), c("#33FFFFFF"),
            Typeface.create("sans-serif-light", Typeface.NORMAL), 4)
    )
}

object Renderer {
    private fun fit(p: Paint, text: String, maxW: Float, size: Float) {
        p.textSize = size
        val m = p.measureText(text)
        if (m > maxW) p.textSize = size * maxW / m
    }

    fun render(w: Int, h: Int, t: Theme, name: String, days: Long, fraction: Float, dateText: String): Bitmap {
        if (t.layout == 1) return renderIos(w, h, t, name, days, fraction, dateText)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val W = w.toFloat(); val H = h.toFloat()
        p.shader = LinearGradient(0f, 0f, W * 0.3f, H, t.top, t.bottom, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, W, H, p)
        p.shader = null
        decorate(c, p, W, H, t)

        val cx = W / 2f; val cy = H * 0.56f; val r = W * 0.33f
        p.style = Paint.Style.STROKE; p.strokeWidth = W * 0.022f; p.strokeCap = Paint.Cap.ROUND
        p.color = t.track
        c.drawCircle(cx, cy, r, p)
        p.color = t.accent
        c.drawArc(RectF(cx - r, cy - r, cx + r, cy + r), -90f, 360f * fraction.coerceIn(0.02f, 1f), false, p)

        p.style = Paint.Style.FILL; p.textAlign = Paint.Align.CENTER; p.typeface = t.font
        val num = maxOf(days, 0L).toString()
        p.color = t.text
        fit(p, num, r * 1.5f, W * 0.30f)
        val ns = p.textSize
        c.drawText(num, cx, cy + ns * 0.34f, p)

        val label = when {
            days > 1 -> "DAYS LEFT"
            days == 1L -> "DAY LEFT"
            days == 0L -> "EXAM DAY"
            else -> "ALL DONE"
        }
        p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        p.letterSpacing = 0.25f; p.color = t.accent
        p.textSize = W * 0.04f
        c.drawText(label, cx, cy + ns * 0.34f + W * 0.075f, p)

        p.letterSpacing = 0.12f; p.color = t.text
        val title = name.trim().ifEmpty { "EXAM" }.uppercase()
        fit(p, title, W * 0.8f, W * 0.055f)
        c.drawText(title, cx, cy - r - W * 0.09f, p)

        p.letterSpacing = 0.15f; p.color = t.sub
        p.textSize = W * 0.034f
        c.drawText(dateText, cx, cy + r + W * 0.12f, p)
        return bmp
    }

    private fun glow(c: Canvas, p: Paint, x: Float, y: Float, r: Float, col: Int) = blob(c, p, x, y, r, col)

    private fun blob(c: Canvas, p: Paint, x: Float, y: Float, r: Float, col: Int) {
        val a = Color.alpha(col)
        val rgb = col and 0x00FFFFFF
        fun al(f: Float): Int = rgb or ((a * f).toInt() shl 24)
        p.shader = RadialGradient(x, y, r,
            intArrayOf(al(1f), al(0.84f), al(0.5f), al(0.16f), al(0f)),
            floatArrayOf(0f, 0.25f, 0.5f, 0.75f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(x, y, r, p)
        p.shader = null
    }

    private fun renderIos(w: Int, h: Int, t: Theme, name: String, days: Long, fraction: Float, dateText: String): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val W = w.toFloat(); val H = h.toFloat(); val cx = W / 2f
        p.shader = LinearGradient(0f, 0f, W * 0.4f, H, t.top, t.bottom, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, W, H, p)
        p.shader = null
        for (b in t.blobs) blob(c, p, W * b.x, H * b.y, W * b.r, b.color)

        p.style = Paint.Style.FILL; p.textAlign = Paint.Align.CENTER
        val title = name.trim().ifEmpty { "EXAM" }.uppercase()
        p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        p.letterSpacing = 0.3f; p.color = t.sub
        fit(p, title, W * 0.8f, W * 0.04f)
        c.drawText(title, cx, H * 0.30f, p)

        val num = maxOf(days, 0L).toString()
        p.typeface = t.font; p.letterSpacing = 0f; p.color = t.text
        fit(p, num, W * 0.78f, W * 0.46f)
        val ns = p.textSize
        p.setShadowLayer(W * 0.04f, 0f, W * 0.012f, Color.parseColor("#26000000"))
        val baseline = H * 0.30f + ns * 0.88f
        c.drawText(num, cx, baseline, p)
        p.clearShadowLayer()

        val label = when {
            days > 1 -> "DAYS LEFT"
            days == 1L -> "DAY LEFT"
            days == 0L -> "EXAM DAY"
            else -> "ALL DONE"
        }
        val top = baseline + W * 0.12f
        val rect = RectF(W * 0.14f, top, W * 0.86f, top + W * 0.25f)
        val rr = W * 0.07f
        p.color = t.glass; c.drawRoundRect(rect, rr, rr, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = W * 0.004f; p.color = Color.parseColor("#66FFFFFF")
        c.drawRoundRect(rect, rr, rr, p)
        p.style = Paint.Style.FILL
        p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        p.letterSpacing = 0.25f; p.color = t.accent; p.textSize = W * 0.04f
        c.drawText(label, cx, top + W * 0.09f, p)
        p.letterSpacing = 0.12f; p.color = t.sub; p.textSize = W * 0.032f
        c.drawText(dateText, cx, top + W * 0.145f, p)

        val bl = rect.left + W * 0.07f; val br = rect.right - W * 0.07f; val by = top + W * 0.195f
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND; p.strokeWidth = W * 0.012f
        p.color = t.track; c.drawLine(bl, by, br, by, p)
        p.color = t.accent; c.drawLine(bl, by, bl + (br - bl) * fraction.coerceIn(0.02f, 1f), by, p)
        return bmp
    }

    private fun decorate(c: Canvas, p: Paint, W: Float, H: Float, t: Theme) {
        p.style = Paint.Style.FILL
        when (t.deco) {
            0 -> {
                glow(c, p, W * 0.2f, H * 0.25f, W * 0.8f, Color.parseColor("#557CF0D4"))
                glow(c, p, W * 0.85f, H * 0.75f, W * 0.9f, Color.parseColor("#66B05CFF"))
            }
            1 -> {
                p.color = Color.parseColor("#33FFFFFF"); c.drawCircle(W / 2, H * 0.86f, W * 0.62f, p)
                p.color = Color.parseColor("#22FFFFFF"); c.drawCircle(W / 2, H * 0.86f, W * 0.9f, p)
            }
            2 -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = 1.5f; p.color = Color.parseColor("#14000000")
                var y = H * 0.04f
                while (y < H) { c.drawLine(W * 0.08f, y, W * 0.92f, y, p); y += H / 38f }
                p.style = Paint.Style.FILL
            }
            3 -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = Color.parseColor("#3300E5FF")
                val top = H * 0.74f
                var y = top
                var step = H * 0.012f
                while (y < H) { c.drawLine(0f, y, W, y, p); step *= 1.35f; y += step }
                for (i in -6..14) c.drawLine(W / 2 + (i - 4) * W * 0.02f, top, W / 2 + (i - 4) * W * 0.28f, H, p)
                p.style = Paint.Style.FILL
                glow(c, p, W * 0.5f, H * 0.2f, W * 0.7f, Color.parseColor("#33FF2BD6"))
            }
            4 -> {
                p.color = Color.parseColor("#22FFFFFF"); c.drawCircle(W * 0.15f, H * 1.0f, W * 0.75f, p)
                p.color = Color.parseColor("#1AFFFFFF"); c.drawCircle(W * 0.95f, H * 1.05f, W * 0.85f, p)
                glow(c, p, W * 0.8f, H * 0.12f, W * 0.5f, Color.parseColor("#44FFD479"))
            }
        }
    }
}
