package com.examcountdown.wallpaper

import android.graphics.*
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import java.util.Random

data class Blob(val x: Float, val y: Float, val r: Float, val color: Int)

data class Theme(
    val name: String, val top: Int, val bottom: Int, val text: Int, val sub: Int,
    val accent: Int, val track: Int, val font: Typeface, val deco: Int,
    val blobs: List<Blob> = emptyList(), val layout: Int = 1, val glass: Int = 0x26FFFFFF,
    val stars: Boolean = false
)

object Themes {
    private fun c(s: String) = Color.parseColor(s)
    private fun b(x: Float, y: Float, r: Float, s: String) = Blob(x, y, r, Color.parseColor(s))
    private val thin = Typeface.create("sans-serif-thin", Typeface.NORMAL)
    private val light = Typeface.create("sans-serif-light", Typeface.NORMAL)
    private val COND = Typeface.create("sans-serif-condensed", Typeface.BOLD)
    val all = listOf(
        Theme("Twilight", c("#1B1B4B"), c("#E8735A"), c("#FFFFFF"), c("#FFE1D0"), c("#FFD2A8"), c("#44FFFFFF"),
            COND, -1, listOf(b(0.15f, 0.12f, 0.80f, "#B35B5BFF"), b(0.90f, 0.35f, 0.70f, "#B3FF8A5C"),
                b(0.20f, 0.92f, 0.85f, "#B3FFB36B"), b(0.90f, 0.95f, 0.60f, "#80FFD2A8")), layout = 2),
        Theme("Rose Quartz", c("#FFE4EC"), c("#F3D4F5"), c("#4A1D3A"), c("#94607F"), c("#C2456B"), c("#26000000"),
            thin, -1, listOf(b(0.10f, 0.12f, 0.75f, "#E6FFB0C8"), b(0.92f, 0.40f, 0.70f, "#D9E0B3FF"),
                b(0.15f, 0.88f, 0.80f, "#CCFFD1B8"), b(0.85f, 0.95f, 0.55f, "#B3FFFFFF")), layout = 3),
        Theme("Obsidian Gold", c("#0B0B0F"), c("#1A1408"), c("#FFFFFF"), c("#CDBF9F"), c("#F5C26B"), c("#33FFFFFF"),
            COND, -1, listOf(b(0.85f, 0.12f, 0.75f, "#99F5C26B"), b(0.05f, 0.55f, 0.70f, "#66B8860B"),
                b(0.80f, 0.92f, 0.80f, "#80F59E0B")), layout = 2),
        Theme("Glacier", c("#E8F4FF"), c("#BFDFFF"), c("#0B2A52"), c("#4F7399"), c("#1D6FD8"), c("#26000000"),
            light, -1, listOf(b(0.12f, 0.15f, 0.75f, "#D98EC8FF"), b(0.92f, 0.35f, 0.70f, "#CCFFFFFF"),
                b(0.20f, 0.85f, 0.80f, "#B35AA9FF"), b(0.90f, 0.95f, 0.60f, "#B3A5E1FF")), 1, c("#66FFFFFF")),
        Theme("Orchid", c("#3A0A5C"), c("#8A1C8E"), c("#FFFFFF"), c("#F3C9F5"), c("#FFD6F5"), c("#44FFFFFF"),
            thin, -1, listOf(b(0.15f, 0.15f, 0.80f, "#CCD946EF"), b(0.95f, 0.50f, 0.70f, "#B3FF5CA8"),
                b(0.15f, 0.92f, 0.80f, "#B35B21B6"), b(0.85f, 0.05f, 0.50f, "#66FFC4F0")), layout = 3),
        Theme("Ember", c("#1A0505"), c("#3A0D0D"), c("#FFFFFF"), c("#FFD0B8"), c("#FFB347"), c("#33FFFFFF"),
            COND, -1, listOf(b(0.20f, 0.18f, 0.80f, "#B3FF4E2A"), b(0.92f, 0.55f, 0.70f, "#99FF8A00"),
                b(0.10f, 0.92f, 0.80f, "#80B3121B")), layout = 2),
        Theme("Lagoon", c("#04202E"), c("#0B5A6B"), c("#FFFFFF"), c("#BFEFF0"), c("#C8F560"), c("#33FFFFFF"),
            light, -1, listOf(b(0.10f, 0.15f, 0.80f, "#B300D5C8"), b(0.95f, 0.50f, 0.70f, "#B31E90FF"),
                b(0.20f, 0.95f, 0.85f, "#9904798A"), b(0.85f, 0.05f, 0.50f, "#66C8F560")), 1),
        Theme("Citrus Pop", c("#FFF3B0"), c("#FFB347"), c("#3A1F00"), c("#7A4A12"), c("#D9480F"), c("#26000000"),
            COND, -1, listOf(b(0.10f, 0.12f, 0.75f, "#E6FFE45C"), b(0.92f, 0.35f, 0.70f, "#CCFF9A3C"),
                b(0.20f, 0.85f, 0.80f, "#B3C8F26B"), b(0.88f, 0.95f, 0.60f, "#B3FF7A59")), layout = 2),
        Theme("Noir Neon", c("#050509"), c("#0D0A1A"), c("#F5F5FF"), c("#8A8FFF"), c("#00F0FF"), c("#3300F0FF"),
            thin, -1, listOf(b(0.15f, 0.15f, 0.80f, "#80FF2BD6"), b(0.95f, 0.60f, 0.70f, "#8000F0FF"),
                b(0.20f, 0.95f, 0.80f, "#66622BFF")), layout = 3),
        Theme("Sand Dune", c("#F5E6D3"), c("#E2B896"), c("#3B2414"), c("#8A5E3F"), c("#B4532A"), c("#26000000"),
            light, -1, listOf(b(0.10f, 0.12f, 0.75f, "#D9F3C9A5"), b(0.92f, 0.40f, 0.70f, "#CCE8A87C"),
                b(0.20f, 0.88f, 0.80f, "#B3D98F5C"), b(0.88f, 0.95f, 0.60f, "#B3FFF1E0")), 1, c("#59FFFFFF")),
        Theme("Cotton Candy", c("#FFD9EC"), c("#D9E6FF"), c("#3A2E5C"), c("#7A6E9B"), c("#5B4B9A"), c("#26000000"),
            light, -1, listOf(b(0.12f, 0.18f, 0.75f, "#E6FF8FC8"), b(0.95f, 0.32f, 0.70f, "#D9B3A0FF"),
                b(0.15f, 0.88f, 0.85f, "#D9FFC9A3"), b(0.88f, 0.92f, 0.65f, "#CC9ED2FF")), 1, c("#59FFFFFF")),
        Theme("Ocean Glass", c("#031B34"), c("#0A4D68"), c("#FFFFFF"), c("#BFEFF5"), c("#7DF9FF"), c("#33FFFFFF"),
            thin, -1, listOf(b(0.10f, 0.15f, 0.80f, "#CC00D2C6"), b(0.95f, 0.45f, 0.75f, "#B31E6BFF"),
                b(0.20f, 0.95f, 0.85f, "#B30A8FB5"), b(0.85f, 0.05f, 0.50f, "#667DF9FF")), 1),
        Theme("Peach Fizz", c("#FF9A8B"), c("#FF6A88"), c("#FFFFFF"), c("#FFF0E8"), c("#FFFFFF"), c("#44FFFFFF"),
            thin, -1, listOf(b(0.85f, 0.12f, 0.70f, "#E6FFD27D"), b(0.05f, 0.45f, 0.70f, "#CCFF4F9A"),
                b(0.90f, 0.75f, 0.75f, "#CCFF8F5A"), b(0.25f, 0.98f, 0.70f, "#B3FFE0C2")), 1),
        Theme("Midnight Mesh", c("#0A0A1F"), c("#1A0B33"), c("#FFFFFF"), c("#B7B4E6"), c("#C7B8FF"), c("#33FFFFFF"),
            thin, -1, listOf(b(0.15f, 0.20f, 0.85f, "#CC4F46E5"), b(0.95f, 0.50f, 0.75f, "#B3D946EF"),
                b(0.10f, 0.90f, 0.80f, "#B3312E81"), b(0.80f, 0.95f, 0.45f, "#6622D3EE")), 1),
        Theme("Lavender Haze", c("#EBDCFF"), c("#C9BBFF"), c("#2E1065"), c("#6B5BA8"), c("#4C2D9E"), c("#26000000"),
            light, -1, listOf(b(0.10f, 0.12f, 0.75f, "#D9A78BFA"), b(0.92f, 0.35f, 0.70f, "#CCF0ABFC"),
                b(0.15f, 0.80f, 0.80f, "#CC93C5FD"), b(0.85f, 0.95f, 0.60f, "#B3FDE68A")), 1, c("#59FFFFFF")),
        Theme("Mint Dew", c("#D9FBEA"), c("#A9F2D2"), c("#064E3B"), c("#3F8A72"), c("#0B7A5A"), c("#26000000"),
            light, -1, listOf(b(0.90f, 0.12f, 0.75f, "#CC6EE7B7"), b(0.05f, 0.40f, 0.70f, "#B35EEAD4"),
                b(0.85f, 0.85f, 0.80f, "#B3BEF264"), b(0.15f, 0.97f, 0.65f, "#B37DD3FC")), 1, c("#59FFFFFF")),
        Theme("Golden Hour", c("#3A1C71"), c("#D76D77"), c("#FFFFFF"), c("#FFE9D6"), c("#FFD89B"), c("#44FFFFFF"),
            thin, -1, listOf(b(0.88f, 0.12f, 0.75f, "#E6FFAF7B"), b(0.05f, 0.50f, 0.70f, "#B36A3093"),
                b(0.90f, 0.80f, 0.80f, "#CCEE9CA7"), b(0.20f, 0.97f, 0.70f, "#B3FFD89B")), 1),
        Theme("Northern Lights", c("#021B1A"), c("#0B1F3A"), c("#FFFFFF"), c("#BDEFE3"), c("#5CFFC4"), c("#33FFFFFF"),
            thin, -1, listOf(b(0.20f, 0.15f, 0.80f, "#B300FFA3"), b(0.95f, 0.40f, 0.70f, "#B300B3FF"),
                b(0.10f, 0.85f, 0.80f, "#998A2BE2"), b(0.85f, 0.95f, 0.50f, "#6600FFD1")), layout = 1, stars = true),
        Theme("Graphite", c("#1C1C1E"), c("#2C2C2E"), c("#FFFFFF"), c("#A1A1A8"), c("#FFFFFF"), c("#33FFFFFF"),
            thin, -1, listOf(b(0.15f, 0.15f, 0.80f, "#555E5CE6"), b(0.95f, 0.55f, 0.70f, "#4064D2FF"),
                b(0.20f, 0.95f, 0.80f, "#33FF6B9E")), 1),
        Theme("Sakura", c("#FFEFF4"), c("#FFD1E3"), c("#5A1E3A"), c("#A0607F"), c("#B03A6E"), c("#26000000"),
            light, -1, listOf(b(0.10f, 0.12f, 0.75f, "#D9FFB3D1"), b(0.92f, 0.35f, 0.70f, "#CCFFC4A8"),
                b(0.15f, 0.80f, 0.80f, "#CCE0BBFF"), b(0.85f, 0.95f, 0.60f, "#B3FFFFFF")), 1, c("#66FFFFFF")),
        Theme("Deep Space", c("#000010"), c("#0D0B2E"), c("#FFFFFF"), c("#A9A7E8"), c("#9D8CFF"), c("#33FFFFFF"),
            thin, -1, listOf(b(0.20f, 0.18f, 0.80f, "#993A1C71"), b(0.90f, 0.50f, 0.70f, "#802B3A9F"),
                b(0.15f, 0.90f, 0.80f, "#807B2FF7")), layout = 1, stars = true)
    )
}

object Renderer {
    fun fit(p: Paint, text: String, maxW: Float, size: Float) {
        p.textSize = size
        val m = p.measureText(text)
        if (m > maxW) p.textSize = size * maxW / m
    }

    fun labelFor(days: Long) = when {
        days > 1 -> "DAYS LEFT"
        days == 1L -> "DAY LEFT"
        days == 0L -> "EXAM DAY"
        else -> "ALL DONE"
    }

    private val medium: Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    private val COND: Typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)

    // ---------------------------------------------------------------- wallpaper
    fun render(
        w: Int, h: Int, t: Theme, name: String, days: Long, fraction: Float,
        dateText: String, quote: String? = null, d: Disp = Disp.of(days)
    ): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val FW = w.toFloat(); val H = h.toFloat()
        background(c, p, FW, H, t)
        // In landscape the portrait design is kept at its natural proportions and centred.
        val W = if (FW > H) H * 0.56f else FW
        c.save()
        c.translate((FW - W) / 2f, 0f)
        val up = if (quote.isNullOrEmpty()) 0f else H * 0.035f
        val bottom = when (t.layout) {
            2 -> editorialContent(c, p, W, H, t, name, d, fraction, dateText, up)
            3 -> minimalContent(c, p, W, H, t, name, d, fraction, dateText, up)
            else -> iosContent(c, p, W, H, t, name, d, fraction, dateText, up)
        }
        if (!quote.isNullOrEmpty()) {
            val left = t.layout == 2
            val width = (W * (if (left) 0.84f else 0.76f)).toInt()
            wrapped(c, quote, if (left) W * 0.08f else W / 2f - width / 2f, bottom + W * 0.09f, width, W * 0.04f, t.sub,
                if (left) Layout.Alignment.ALIGN_NORMAL else Layout.Alignment.ALIGN_CENTER, 4, H * 0.9f, true)
        }
        c.restore()
        return bmp
    }

    private fun background(c: Canvas, p: Paint, W: Float, H: Float, t: Theme) {
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, 0f, W * 0.4f, H, t.top, t.bottom, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, W, H, p)
        p.shader = null
        for (b in t.blobs) blob(c, p, W * b.x, H * b.y, W * b.r, b.color)
        if (t.stars) stars(c, p, W, H)
    }

    /** Left-aligned, bold, editorial layout. */
    private fun editorialContent(
        c: Canvas, p: Paint, W: Float, H: Float, t: Theme, name: String,
        d: Disp, fraction: Float, dateText: String, up: Float
    ): Float {
        val x = W * 0.08f
        p.style = Paint.Style.FILL; p.textAlign = Paint.Align.LEFT
        p.typeface = t.font; p.letterSpacing = 0f; p.color = t.text
        fit(p, d.num, W * 0.84f, W * 0.58f)
        val ns = p.textSize
        val base = H * 0.46f - up + ns * 0.30f
        p.setShadowLayer(W * 0.03f, 0f, W * 0.01f, Color.parseColor("#33000000"))
        c.drawText(d.num, x, base, p)
        p.clearShadowLayer()
        p.color = t.accent
        c.drawRoundRect(RectF(x, base + W * 0.06f, x + W * 0.20f, base + W * 0.076f), W * 0.008f, W * 0.008f, p)

        val title = name.trim().ifEmpty { "EXAM" }.uppercase()
        p.typeface = COND; p.letterSpacing = 0.06f; p.color = t.text
        fit(p, title, W * 0.84f, W * 0.06f)
        val nameY = base + W * 0.17f
        c.drawText(title, x, nameY, p)

        p.typeface = medium; p.letterSpacing = 0.25f; p.color = t.accent; p.textSize = W * 0.034f
        val labelY = nameY + W * 0.075f
        c.drawText(d.label, x, labelY, p)
        p.letterSpacing = 0.15f; p.color = t.sub; p.textSize = W * 0.03f
        val dateY = labelY + W * 0.06f
        c.drawText(dateText, x, dateY, p)
        p.letterSpacing = 0f

        val barY = dateY + W * 0.07f
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND; p.strokeWidth = W * 0.010f
        p.color = t.track; c.drawLine(x, barY, W - x, barY, p)
        p.color = t.accent; c.drawLine(x, barY, x + (W - 2 * x) * fraction.coerceIn(0.02f, 1f), barY, p)
        p.style = Paint.Style.FILL
        return barY
    }

    /** Huge thin number in the style of a lock-screen clock, no card. */
    private fun minimalContent(
        c: Canvas, p: Paint, W: Float, H: Float, t: Theme, name: String,
        d: Disp, fraction: Float, dateText: String, up: Float
    ): Float {
        val cx = W / 2f
        p.style = Paint.Style.FILL; p.textAlign = Paint.Align.CENTER
        p.typeface = t.font; p.letterSpacing = 0f; p.color = t.text
        fit(p, d.num, W * 0.86f, W * 0.50f)
        val ns = p.textSize
        val base = H * 0.46f - up + ns * 0.35f
        val title = name.trim().ifEmpty { "EXAM" }.uppercase()

        p.typeface = medium; p.letterSpacing = 0.3f; p.color = t.sub
        fit(p, title, W * 0.8f, W * 0.04f)
        c.drawText(title, cx, base - ns * 0.74f - W * 0.05f, p)

        p.typeface = t.font; p.letterSpacing = 0f; p.color = t.text; p.textSize = ns
        p.setShadowLayer(W * 0.04f, 0f, W * 0.012f, Color.parseColor("#26000000"))
        c.drawText(d.num, cx, base, p)
        p.clearShadowLayer()

        p.typeface = medium; p.letterSpacing = 0.28f; p.color = t.accent; p.textSize = W * 0.04f
        c.drawText(d.label, cx, base + W * 0.10f, p)
        p.letterSpacing = 0.15f; p.color = t.sub; p.textSize = W * 0.032f
        c.drawText(dateText, cx, base + W * 0.16f, p)
        p.letterSpacing = 0f

        val by = base + W * 0.22f
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND; p.strokeWidth = W * 0.008f
        p.color = t.track; c.drawLine(cx - W * 0.18f, by, cx + W * 0.18f, by, p)
        p.color = t.accent; c.drawLine(cx - W * 0.18f, by, cx - W * 0.18f + W * 0.36f * fraction.coerceIn(0.02f, 1f), by, p)
        p.style = Paint.Style.FILL
        return by
    }

    private fun iosContent(
        c: Canvas, p: Paint, W: Float, H: Float, t: Theme, name: String,
        d: Disp, fraction: Float, dateText: String, up: Float
    ): Float {
        val cx = W / 2f
        p.style = Paint.Style.FILL; p.textAlign = Paint.Align.CENTER
        val title = name.trim().ifEmpty { "EXAM" }.uppercase()
        p.typeface = medium
        p.letterSpacing = 0.3f; p.color = t.sub
        fit(p, title, W * 0.8f, W * 0.04f)
        c.drawText(title, cx, H * 0.30f - up, p)

        val num = d.num
        p.typeface = t.font; p.letterSpacing = 0f; p.color = t.text
        fit(p, num, W * 0.78f, W * 0.46f)
        val ns = p.textSize
        p.setShadowLayer(W * 0.04f, 0f, W * 0.012f, Color.parseColor("#26000000"))
        val baseline = H * 0.30f - up + ns * 0.88f
        c.drawText(num, cx, baseline, p)
        p.clearShadowLayer()

        val top = baseline + W * 0.12f
        val rect = RectF(W * 0.14f, top, W * 0.86f, top + W * 0.25f)
        val rr = W * 0.07f
        p.color = t.glass; c.drawRoundRect(rect, rr, rr, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = W * 0.004f; p.color = Color.parseColor("#66FFFFFF")
        c.drawRoundRect(rect, rr, rr, p)
        p.style = Paint.Style.FILL
        p.typeface = medium
        p.letterSpacing = 0.25f; p.color = t.accent; p.textSize = W * 0.04f
        c.drawText(d.label, cx, top + W * 0.09f, p)
        p.letterSpacing = 0.12f; p.color = t.sub; p.textSize = W * 0.032f
        c.drawText(dateText, cx, top + W * 0.145f, p)
        p.letterSpacing = 0f

        val bl = rect.left + W * 0.07f; val br = rect.right - W * 0.07f; val by = top + W * 0.195f
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND; p.strokeWidth = W * 0.012f
        p.color = t.track; c.drawLine(bl, by, br, by, p)
        p.color = t.accent; c.drawLine(bl, by, bl + (br - bl) * fraction.coerceIn(0.02f, 1f), by, p)
        p.style = Paint.Style.FILL
        return rect.bottom
    }

    // ------------------------------------------------------------------- widget
    fun renderWidget(
        w: Int, h: Int, t: Theme, name: String, days: Long, fraction: Float,
        dateText: String, quote: String?, custom: ((Canvas, Float, Float) -> Unit)? = null,
        d: Disp = Disp.of(days)
    ): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val W = w.toFloat(); val H = h.toFloat(); val m = minOf(W, H)
        val rad = m * 0.16f
        val clip = Path()
        clip.addRoundRect(RectF(0f, 0f, W, H), rad, rad, Path.Direction.CW)
        c.clipPath(clip)

        p.style = Paint.Style.FILL
        if (custom != null) {
            custom(c, W, H)
        } else {
            p.shader = LinearGradient(0f, 0f, W * 0.5f, H, t.top, t.bottom, Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, W, H, p)
            p.shader = null
            if (t.blobs.isNotEmpty()) {
                val s = (W + H) / 2f
                for (b in t.blobs) blob(c, p, W * b.x, H * b.y, s * b.r * 1.2f, b.color)
            } else {
                glow(c, p, W * 0.85f, H * 0.1f, m, (t.accent and 0x00FFFFFF) or (0x55 shl 24))
            }
            if (t.stars) stars(c, p, W, H)
        }

        val num = d.num
        val title = name.trim().ifEmpty { "EXAM" }.uppercase()
        val hasQ = !quote.isNullOrEmpty()
        val wide = W > H * 1.5f

        if (wide) {
            val pad = H * 0.12f
            val r = H * 0.30f; val sw = H * 0.05f
            val cx = pad + r + sw; val cy = H / 2f
            ring(c, p, cx, cy, r, sw, t, fraction)
            ringNumber(c, p, cx, cy, r, t, num, d.label)
            val x0 = cx + r + H * 0.16f
            val tw = W - x0 - pad
            p.textAlign = Paint.Align.LEFT; p.typeface = medium
            p.letterSpacing = 0.1f; p.color = t.text
            fit(p, title, tw, H * 0.13f)
            c.drawText(title, x0, if (hasQ) H * 0.24f else H * 0.46f, p)
            p.letterSpacing = 0.12f; p.color = t.sub
            fit(p, dateText, tw, H * 0.095f)
            c.drawText(dateText, x0, if (hasQ) H * 0.40f else H * 0.64f, p)
            p.letterSpacing = 0f
            if (hasQ) wrapped(c, quote!!, x0, H * 0.50f, tw.toInt(), H * 0.085f, t.text,
                Layout.Alignment.ALIGN_NORMAL, 3, H * 0.93f, false)
        } else {
            val r = if (hasQ) m * 0.25f else m * 0.30f
            val cy = if (hasQ) H * 0.40f else H * 0.54f
            val cx = W / 2f; val sw = m * 0.045f
            ring(c, p, cx, cy, r, sw, t, fraction)
            ringNumber(c, p, cx, cy, r, t, num, d.label)
            p.textAlign = Paint.Align.CENTER; p.typeface = medium
            p.letterSpacing = 0.12f; p.color = t.sub
            fit(p, title, W * 0.8f, m * 0.075f)
            c.drawText(title, cx, cy - r - sw - m * 0.04f, p)
            p.letterSpacing = 0f
            if (hasQ) wrapped(c, quote!!, cx - W * 0.42f, cy + r + sw + m * 0.06f, (W * 0.84f).toInt(),
                m * 0.07f, t.text, Layout.Alignment.ALIGN_CENTER, 3, H * 0.94f, false)
        }
        return bmp
    }

    private class WCtx(val bmp: Bitmap, val c: Canvas, val p: Paint, val W: Float, val H: Float, val m: Float)

    private fun startWidget(w: Int, h: Int, t: Theme, custom: ((Canvas, Float, Float) -> Unit)?): WCtx {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val W = w.toFloat(); val H = h.toFloat(); val m = minOf(W, H)
        val rad = m * 0.16f
        val clip = Path()
        clip.addRoundRect(RectF(0f, 0f, W, H), rad, rad, Path.Direction.CW)
        c.clipPath(clip)
        p.style = Paint.Style.FILL
        if (custom != null) {
            custom(c, W, H)
        } else {
            p.shader = LinearGradient(0f, 0f, W * 0.5f, H, t.top, t.bottom, Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, W, H, p)
            p.shader = null
            if (t.blobs.isNotEmpty()) {
                val s = (W + H) / 2f
                for (b in t.blobs) blob(c, p, W * b.x, H * b.y, s * b.r * 1.2f, b.color)
            } else {
                glow(c, p, W * 0.85f, H * 0.1f, m, (t.accent and 0x00FFFFFF) or (0x55 shl 24))
            }
            if (t.stars) stars(c, p, W, H)
        }
        return WCtx(bmp, c, p, W, H, m)
    }

    private fun withAlpha(col: Int, a: Int): Int = (col and 0x00FFFFFF) or (a shl 24)

    /** 1x1 widget: just the ring and the number. */
    fun renderTiny(w: Int, h: Int, t: Theme, d: Disp, fraction: Float, custom: ((Canvas, Float, Float) -> Unit)?): Bitmap {
        val x = startWidget(w, h, t, custom)
        val c = x.c; val p = x.p
        val r = x.m * 0.36f
        ring(c, p, x.W / 2f, x.H / 2f, r, x.m * 0.07f, t, fraction)
        p.style = Paint.Style.FILL; p.textAlign = Paint.Align.CENTER
        p.typeface = t.font; p.letterSpacing = 0f; p.color = t.text
        fit(p, d.num, r * 1.5f, r * 1.2f)
        c.drawText(d.num, x.W / 2f, x.H / 2f + p.textSize * 0.34f, p)
        return x.bmp
    }

    /** Calendar-style widget: every day since the start is crossed off. */
    fun renderCalendar(
        w: Int, h: Int, t: Theme, name: String, days: Long, startDay: Long, examDay: Long,
        today: Long, custom: ((Canvas, Float, Float) -> Unit)?
    ): Bitmap {
        val x = startWidget(w, h, t, custom)
        val c = x.c; val p = x.p; val W = x.W; val H = x.H; val m = x.m
        val pad = m * 0.09f
        p.style = Paint.Style.FILL; p.typeface = medium; p.letterSpacing = 0.1f
        p.textAlign = Paint.Align.LEFT; p.color = t.text
        val title = name.trim().ifEmpty { "EXAM" }.uppercase()
        fit(p, title, W * 0.55f - pad, H * 0.11f)
        c.drawText(title, pad, pad + H * 0.09f, p)
        val right = if (days > 0) "$days DAYS" else if (days == 0L) "EXAM DAY" else "DONE"
        p.textAlign = Paint.Align.RIGHT; p.color = t.accent
        fit(p, right, W * 0.38f, H * 0.10f)
        c.drawText(right, W - pad, pad + H * 0.09f, p)
        p.letterSpacing = 0f

        val startEff = if (startDay in 0..today) startDay else today
        val span = maxOf(1L, examDay - startEff + 1)
        val per = if (span <= 56L) 1L else 7L
        val cells = ((span + per - 1) / per).toInt()
        val cols = 7
        val rows = (cells + cols - 1) / cols
        val top = pad * 1.6f + H * 0.12f
        val availW = W - 2 * pad
        val availH = H - pad - top
        val cell = minOf(availW / cols, availH / rows)
        val left = (W - cell * cols) / 2f
        val rr = cell * 0.34f
        for (i in 0 until cells) {
            val cx = left + (i % cols) * cell + cell / 2f
            val cy = top + (i / cols) * cell + cell / 2f
            val d0 = startEff + i * per
            val d1 = minOf(d0 + per - 1, examDay)
            val isExam = i == cells - 1
            when {
                isExam && today <= examDay -> {
                    p.style = Paint.Style.FILL; p.color = t.text
                    c.drawCircle(cx, cy, rr * 0.8f, p)
                    p.style = Paint.Style.STROKE; p.strokeWidth = cell * 0.07f; p.color = t.accent
                    c.drawCircle(cx, cy, rr * 1.1f, p)
                }
                d1 < today -> {
                    p.style = Paint.Style.FILL; p.color = withAlpha(t.accent, 0x4D)
                    c.drawCircle(cx, cy, rr, p)
                    p.style = Paint.Style.STROKE; p.strokeWidth = cell * 0.07f; p.strokeCap = Paint.Cap.ROUND
                    p.color = withAlpha(t.text, 0xB0)
                    val k = rr * 0.5f
                    c.drawLine(cx - k, cy - k, cx + k, cy + k, p)
                    c.drawLine(cx - k, cy + k, cx + k, cy - k, p)
                }
                today in d0..d1 -> {
                    p.style = Paint.Style.FILL; p.color = t.accent
                    c.drawCircle(cx, cy, rr, p)
                }
                else -> {
                    p.style = Paint.Style.STROKE; p.strokeWidth = cell * 0.06f; p.color = t.track
                    c.drawCircle(cx, cy, rr, p)
                }
            }
        }
        p.style = Paint.Style.FILL
        return x.bmp
    }

    /** Lists up to four upcoming exams with the days left for each. */
    fun renderList(
        w: Int, h: Int, t: Theme, items: List<ListItem>, urgencyOn: Boolean,
        custom: ((Canvas, Float, Float) -> Unit)?
    ): Bitmap {
        val x = startWidget(w, h, t, custom)
        val c = x.c; val p = x.p; val W = x.W; val H = x.H; val m = x.m
        val pad = m * 0.10f
        p.style = Paint.Style.FILL
        if (items.isEmpty()) {
            p.textAlign = Paint.Align.CENTER; p.typeface = medium; p.color = t.sub; p.letterSpacing = 0.1f
            fit(p, "NO UPCOMING EXAMS", W * 0.8f, H * 0.12f)
            c.drawText("NO UPCOMING EXAMS", W / 2f, H / 2f, p)
            p.letterSpacing = 0f
            return x.bmp
        }
        val n = items.size
        val rowH = minOf((H - 2 * pad) / n, H * 0.34f)
        val total = rowH * n
        val y0 = (H - total) / 2f
        for ((i, it) in items.withIndex()) {
            val cy = y0 + rowH * i + rowH / 2f
            val col = if (urgencyOn) Updater.urgency(it.days) else t.accent
            val label = if (it.days == 1L) "DAY" else "DAYS"
            p.textAlign = Paint.Align.RIGHT; p.typeface = medium; p.letterSpacing = 0.15f
            p.textSize = rowH * 0.17f; p.color = t.sub
            val lw = p.measureText(label)
            c.drawText(label, W - pad, cy + rowH * 0.28f, p)
            p.letterSpacing = 0f
            p.typeface = t.font; p.color = col
            val numS = it.days.toString()
            fit(p, numS, W * 0.28f, rowH * 0.62f)
            c.drawText(numS, W - pad - lw - rowH * 0.12f, cy + p.textSize * 0.34f, p)
            p.textAlign = Paint.Align.LEFT; p.typeface = medium; p.letterSpacing = 0.08f; p.color = t.text
            fit(p, it.name.uppercase(), W * 0.5f - pad, rowH * 0.30f)
            c.drawText(it.name.uppercase(), pad, cy + p.textSize * 0.34f, p)
            p.letterSpacing = 0f
            if (i < n - 1) {
                p.style = Paint.Style.STROKE; p.strokeWidth = 1.5f; p.color = t.track
                c.drawLine(pad, cy + rowH / 2f, W - pad, cy + rowH / 2f, p)
                p.style = Paint.Style.FILL
            }
        }
        return x.bmp
    }

    // ------------------------------------------------------------------ helpers
    private fun ring(c: Canvas, p: Paint, cx: Float, cy: Float, r: Float, sw: Float, t: Theme, fraction: Float) {
        p.style = Paint.Style.STROKE; p.strokeWidth = sw; p.strokeCap = Paint.Cap.ROUND
        p.color = t.track; c.drawCircle(cx, cy, r, p)
        p.color = t.accent
        c.drawArc(RectF(cx - r, cy - r, cx + r, cy + r), -90f, 360f * fraction.coerceIn(0.02f, 1f), false, p)
        p.style = Paint.Style.FILL
    }

    private fun ringNumber(c: Canvas, p: Paint, cx: Float, cy: Float, r: Float, t: Theme, num: String, label: String) {
        p.style = Paint.Style.FILL; p.textAlign = Paint.Align.CENTER
        p.typeface = t.font; p.letterSpacing = 0f; p.color = t.text
        fit(p, num, r * 1.45f, r * 1.0f)
        val ns = p.textSize
        c.drawText(num, cx, cy + ns * 0.30f, p)
        p.typeface = medium; p.letterSpacing = 0.2f; p.color = t.accent
        p.textSize = r * 0.17f
        c.drawText(label, cx, cy + ns * 0.30f + r * 0.27f, p)
        p.letterSpacing = 0f
    }

    fun wrapped(
        c: Canvas, text: String, x: Float, top: Float, width: Int, size: Float, color: Int,
        align: Layout.Alignment, maxLines: Int, maxBottom: Float, thin: Boolean, shadow: Boolean = false
    ) {
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
        tp.color = color; tp.textSize = size
        if (shadow) tp.setShadowLayer(size * 0.15f, 0f, size * 0.05f, 0x66000000)
        tp.typeface = Typeface.create(if (thin) "sans-serif-light" else "sans-serif", Typeface.ITALIC)
        val s = "\u201C" + text + "\u201D"
        val lay = StaticLayout.Builder.obtain(s, 0, s.length, tp, width)
            .setAlignment(align).setMaxLines(maxLines)
            .setEllipsize(TextUtils.TruncateAt.END).setLineSpacing(0f, 1.12f).build()
        val y = minOf(top, maxBottom - lay.height)
        c.save(); c.translate(x, y); lay.draw(c); c.restore()
    }

    private fun stars(c: Canvas, p: Paint, W: Float, H: Float) {
        val rnd = Random(7)
        p.style = Paint.Style.FILL
        for (i in 0 until 140) {
            val x = rnd.nextFloat() * W; val y = rnd.nextFloat() * H; val s = rnd.nextFloat()
            p.color = Color.argb((60 + s * 160).toInt(), 255, 255, 255)
            c.drawCircle(x, y, W * 0.0015f + s * W * 0.0035f, p)
        }
    }

    private fun glow(c: Canvas, p: Paint, x: Float, y: Float, r: Float, col: Int) = blob(c, p, x, y, r, col)

    private fun blob(c: Canvas, p: Paint, x: Float, y: Float, r: Float, col: Int) {
        val a = Color.alpha(col)
        val rgb = col and 0x00FFFFFF
        fun al(f: Float): Int = rgb or ((a * f).toInt() shl 24)
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(x, y, r,
            intArrayOf(al(1f), al(0.84f), al(0.5f), al(0.16f), al(0f)),
            floatArrayOf(0f, 0.25f, 0.5f, 0.75f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(x, y, r, p)
        p.shader = null
    }
}
