package com.examcountdown.wallpaper

import android.app.WallpaperManager
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Rect
import android.graphics.Typeface
import android.os.Build
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.work.*
import org.json.JSONArray
import org.json.JSONObject
import java.time.DayOfWeek
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.concurrent.TimeUnit

data class Exam(val name: String, val day: Long, val start: Long)

data class Settings(
    var name: String = "Final Exam", var examDay: Long = -1, var startDay: Long = -1,
    var theme: Int = 0, var quote: Boolean = true,
    var mode: Int = 0, var style: Int = 0, var dim: Int = 25, var blur: Int = 0, var pos: Int = 1,
    var acc: Int = 0, var ink: Int = 0, var fx: Int = 50, var fy: Int = 50,
    var startSet: Boolean = false,
    var extra: List<Exam> = emptyList(),
    var notify: Int = 1, var notifyHour: Int = 8,
    var urgency: Boolean = false,
    var qcat: Int = 0, var custom: String = "",
    var unit: Int = 0, var skip: Int = 0,
    var slideshow: Boolean = false, var photoSel: Int = 0,
    var font: Int = 0, var goalHours: Int = 3
)

data class Disp(val num: String, val label: String) {
    companion object {
        fun of(days: Long): Disp = Disp(maxOf(days, 0L).toString(), Renderer.labelFor(days))
    }
}

data class ListItem(val name: String, val days: Long)

object Fonts {
    val names = listOf("Theme default", "Thin", "Light", "Bold", "Condensed", "Serif", "Mono", "Casual")
    fun face(i: Int): Typeface? = when (i) {
        1 -> Typeface.create("sans-serif-thin", Typeface.NORMAL)
        2 -> Typeface.create("sans-serif-light", Typeface.NORMAL)
        3 -> Typeface.create("sans-serif", Typeface.BOLD)
        4 -> Typeface.create("sans-serif-condensed", Typeface.BOLD)
        5 -> Typeface.create("serif", Typeface.NORMAL)
        6 -> Typeface.create("monospace", Typeface.BOLD)
        7 -> Typeface.create("casual", Typeface.NORMAL)
        else -> null
    }
}

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("exam_prefs", Context.MODE_PRIVATE)

    fun toJson(s: Settings): JSONObject {
        val o = JSONObject()
        o.put("name", s.name); o.put("examDay", s.examDay); o.put("startDay", s.startDay)
        o.put("theme", s.theme); o.put("quote", s.quote)
        o.put("mode", s.mode); o.put("style", s.style); o.put("dim", s.dim); o.put("blur", s.blur)
        o.put("pos", s.pos); o.put("acc", s.acc); o.put("ink", s.ink); o.put("fx", s.fx); o.put("fy", s.fy)
        o.put("startSet", s.startSet)
        val arr = JSONArray()
        for (e in s.extra) {
            val x = JSONObject()
            x.put("n", e.name); x.put("d", e.day); x.put("s", e.start)
            arr.put(x)
        }
        o.put("extra", arr)
        o.put("notify", s.notify); o.put("notifyHour", s.notifyHour); o.put("urgency", s.urgency)
        o.put("qcat", s.qcat); o.put("custom", s.custom); o.put("unit", s.unit); o.put("skip", s.skip)
        o.put("slideshow", s.slideshow); o.put("photoSel", s.photoSel)
        o.put("font", s.font); o.put("goalHours", s.goalHours)
        return o
    }

    fun fromJson(o: JSONObject): Settings {
        val extra = ArrayList<Exam>()
        val arr = o.optJSONArray("extra")
        if (arr != null) {
            for (i in 0 until arr.length()) {
                val x = arr.getJSONObject(i)
                extra.add(Exam(x.optString("n", "Exam"), x.optLong("d", -1), x.optLong("s", -1)))
            }
        }
        return Settings(
            name = o.optString("name", "Final Exam"), examDay = o.optLong("examDay", -1),
            startDay = o.optLong("startDay", -1), theme = o.optInt("theme", 0),
            quote = o.optBoolean("quote", true), mode = o.optInt("mode", 0),
            style = o.optInt("style", 0), dim = o.optInt("dim", 25), blur = o.optInt("blur", 0),
            pos = o.optInt("pos", 1), acc = o.optInt("acc", 0), ink = o.optInt("ink", 0),
            fx = o.optInt("fx", 50), fy = o.optInt("fy", 50), startSet = o.optBoolean("startSet", false),
            extra = extra, notify = o.optInt("notify", 1), notifyHour = o.optInt("notifyHour", 8),
            urgency = o.optBoolean("urgency", false), qcat = o.optInt("qcat", 0),
            custom = o.optString("custom", ""), unit = o.optInt("unit", 0), skip = o.optInt("skip", 0),
            slideshow = o.optBoolean("slideshow", false), photoSel = o.optInt("photoSel", 0),
            font = o.optInt("font", 0), goalHours = o.optInt("goalHours", 3)
        )
    }

    fun load(c: Context): Settings {
        val raw = sp(c).getString("cfg_json", null)
        if (raw != null) {
            try { return fromJson(JSONObject(raw)) } catch (e: Exception) { }
        }
        return Settings()
    }

    fun save(c: Context, s: Settings) {
        sp(c).edit().putString("cfg_json", toJson(s).toString()).apply()
    }
}

/** Real physical screen size (including status and navigation bars), always portrait. */
object Screen {
    fun size(ctx: Context): Pair<Int, Int> {
        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        var a: Int
        var b: Int
        if (Build.VERSION.SDK_INT >= 30) {
            val bounds = wm.maximumWindowMetrics.bounds
            a = bounds.width(); b = bounds.height()
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(dm)
            a = dm.widthPixels; b = dm.heightPixels
        }
        return Pair(minOf(a, b), maxOf(a, b))
    }
}

object Updater {
    // ---------------------------------------------------------------- exams
    /** The exam to show: the next upcoming one, or the most recent if all have passed. */
    fun effective(s: Settings, today: Long): Settings {
        val all = ArrayList<Exam>()
        if (s.examDay >= 0) all.add(Exam(s.name, s.examDay, s.startDay))
        all.addAll(s.extra)
        if (all.isEmpty()) return s
        val up = all.filter { it.day >= today }.minByOrNull { it.day }
        val e = up ?: all.maxByOrNull { it.day } ?: return s
        return s.copy(name = e.name, examDay = e.day, startDay = e.start)
    }

    fun items(s: Settings, today: Long): List<ListItem> {
        val all = ArrayList<Exam>()
        if (s.examDay >= 0) all.add(Exam(s.name, s.examDay, s.startDay))
        all.addAll(s.extra)
        return all.filter { it.day >= today }.sortedBy { it.day }.take(4).map { ListItem(it.name, it.day - today) }
    }

    fun fraction(s: Settings, today: Long): Float {
        val start = if (s.startDay in 0..today) s.startDay else today
        val total = maxOf(1L, s.examDay - start)
        return (s.examDay - today).toFloat() / total
    }

    fun dateText(s: Settings) = LocalDate.ofEpochDay(s.examDay)
        .format(DateTimeFormatter.ofPattern("dd MMM yyyy", Locale.getDefault())).uppercase()

    fun urgency(days: Long): Int = when {
        days > 30 -> 0xFF34D399.toInt()
        days > 14 -> 0xFFFBBF24.toInt()
        days > 7 -> 0xFFFB923C.toInt()
        else -> 0xFFF43F5E.toInt()
    }

    fun studyDays(e: Settings, today: Long): Long {
        var n = 0L
        var d = today + 1
        while (d <= e.examDay && d < today + 1500) {
            val dow = LocalDate.ofEpochDay(d).dayOfWeek
            val skipIt = (e.skip == 1 && dow == DayOfWeek.SUNDAY) ||
                (e.skip == 2 && (dow == DayOfWeek.SUNDAY || dow == DayOfWeek.SATURDAY))
            if (!skipIt) n++
            d++
        }
        return n
    }

    fun disp(e: Settings, today: Long): Disp {
        val days = e.examDay - today
        if (days <= 0L) return Disp.of(days)
        return when (e.unit) {
            1 -> if (days >= 7) Disp((days / 7).toString(), "WEEKS + " + (days % 7) + " DAYS") else Disp.of(days)
            2 -> {
                val h = Duration.between(LocalDateTime.now(), LocalDate.ofEpochDay(e.examDay).atStartOfDay()).toHours()
                Disp(maxOf(h, 0L).toString(), "HOURS LEFT")
            }
            else -> if (e.skip > 0) Disp(studyDays(e, today).toString(), "STUDY DAYS LEFT") else Disp.of(days)
        }
    }

    fun quoteFor(e: Settings, today: Long): String? {
        if (!e.quote) return null
        val c = e.custom.trim()
        if (c.isNotEmpty()) return c
        return Quotes.forDay(today, e.qcat)
    }

    // --------------------------------------------------------------- design
    private fun themeFor(e: Settings, idx: Int, days: Long): Theme {
        var t = Themes.all[idx.coerceIn(0, Themes.all.size - 1)]
        if (e.urgency) t = t.copy(accent = urgency(days))
        val f = Fonts.face(e.font)
        if (f != null) t = t.copy(font = f)
        return t
    }

    private fun optsOf(e: Settings, days: Long) = PhotoOpts(
        e.style, e.dim, e.blur, e.pos, e.acc, e.ink, e.fx, e.fy,
        if (e.urgency) urgency(days) else 0, e.font
    )

    /** (mode, index) of the chosen design. */
    fun designOf(s: Settings): Pair<Int, Int> =
        Pair(s.mode, if (s.mode == 1) s.style else s.theme)

    fun usesPhoto(s: Settings) = s.mode == 1

    fun wallpaperBitmap(ctx: Context, s: Settings, w: Int, h: Int, today: Long, preview: Boolean): Bitmap {
        val d = designOf(s)
        return bitmapFor(ctx, s, d.first, d.second, w, h, today, preview)
    }

    /** mode 0 = gradient theme #index, mode 1 = photo overlay style #index. */
    fun bitmapFor(ctx: Context, s: Settings, mode: Int, index: Int, w: Int, h: Int, today: Long, preview: Boolean): Bitmap {
        val e = effective(s, today)
        val days = e.examDay - today
        val q = quoteFor(e, today)
        val d = disp(e, today)
        if (mode == 1) {
            val pi = PhotoStore.indexFor(ctx, e, today)
            val photo = if (preview) PhotoStore.cached(ctx, pi) else PhotoStore.load(ctx, pi, w, h)
            val o = optsOf(e, days).copy(style = index)
            val out = PhotoRenderer.render(photo, w, h, o, e.name, days, fraction(e, today), dateText(e), q, d)
            if (!preview) photo?.recycle()
            return out
        }
        return Renderer.render(w, h, themeFor(e, index, days), e.name, days, fraction(e, today), dateText(e), q, d)
    }

    /** kind: 0 countdown, 1 tiny, 2 calendar, 3 exam list. */
    fun widgetBitmap(
        ctx: Context, s: Settings, kind: Int, w: Int, h: Int, today: Long,
        allowQuote: Boolean, preview: Boolean
    ): Bitmap {
        val e = effective(s, today)
        val days = e.examDay - today
        val design = designOf(e)
        val theme: Theme
        var custom: ((Canvas, Float, Float) -> Unit)? = null
        var photo: Bitmap? = null
        if (design.first == 1) {
            val pi = PhotoStore.indexFor(ctx, e, today)
            photo = if (preview) PhotoStore.cached(ctx, pi) else PhotoStore.load(ctx, pi, w, h)
            val pair = PhotoRenderer.widgetBackground(photo, optsOf(e, days), w, h)
            custom = pair.first
            theme = pair.second
        } else {
            theme = themeFor(e, design.second, days)
        }
        val frac = fraction(e, today)
        val out = when (kind) {
            1 -> Renderer.renderTiny(w, h, theme, disp(e, today), frac, custom)
            2 -> Renderer.renderCalendar(w, h, theme, e.name, days, e.startDay, e.examDay, today, custom)
            3 -> Renderer.renderList(w, h, theme, items(s, today), e.urgency, custom)
            else -> Renderer.renderWidget(w, h, theme, e.name, days, frac, dateText(e),
                if (allowQuote) quoteFor(e, today) else null, custom, disp(e, today))
        }
        if (!preview) photo?.recycle()
        return out
    }

    fun refreshWidgets(ctx: Context) {
        try {
            val mgr = AppWidgetManager.getInstance(ctx)
            val classes = listOf<Class<*>>(CountdownWidget::class.java, TinyWidget::class.java,
                CalendarWidget::class.java, ListWidget::class.java)
            for ((i, cls) in classes.withIndex()) {
                val ids = mgr.getAppWidgetIds(ComponentName(ctx, cls))
                for (id in ids) WidgetUpdater.update(ctx, mgr, id, i)
            }
        } catch (e: Exception) { }
    }

    fun isLiveActive(ctx: Context): Boolean = try {
        WallpaperManager.getInstance(ctx).wallpaperInfo?.packageName == ctx.packageName
    } catch (e: Exception) { false }
}

class DailyWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        try { Updater.refreshWidgets(applicationContext) } catch (e: Exception) { }
        try { Notifier.check(applicationContext) } catch (e: Exception) { }
        Scheduler.scheduleMidnight(applicationContext)
        return Result.success()
    }
}

object Scheduler {
    fun schedule(ctx: Context) {
        val wm = WorkManager.getInstance(ctx)
        wm.enqueueUniquePeriodicWork("periodic", ExistingPeriodicWorkPolicy.KEEP,
            PeriodicWorkRequestBuilder<DailyWorker>(3, TimeUnit.HOURS).build())
        scheduleMidnight(ctx)
    }

    fun scheduleMidnight(ctx: Context) {
        val now = LocalDateTime.now()
        val next = now.toLocalDate().plusDays(1).atTime(0, 5)
        val delay = Duration.between(now, next).toMillis()
        WorkManager.getInstance(ctx).enqueueUniqueWork("midnight", ExistingWorkPolicy.APPEND_OR_REPLACE,
            OneTimeWorkRequestBuilder<DailyWorker>().setInitialDelay(delay, TimeUnit.MILLISECONDS).build())
    }
}
