package com.examcountdown.wallpaper

import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap
import androidx.work.*
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.concurrent.TimeUnit

data class Settings(
    var name: String = "Final Exam", var examDay: Long = -1, var startDay: Long = -1,
    var theme: Int = 0, var target: Int = 2, var last: Long = -1
)

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("exam_prefs", Context.MODE_PRIVATE)
    fun load(c: Context): Settings {
        val p = sp(c)
        return Settings(p.getString("name", "Final Exam") ?: "Final Exam", p.getLong("exam", -1),
            p.getLong("start", -1), p.getInt("theme", 0), p.getInt("target", 2), p.getLong("last", -1))
    }
    fun save(c: Context, s: Settings) {
        sp(c).edit().putString("name", s.name).putLong("exam", s.examDay).putLong("start", s.startDay)
            .putInt("theme", s.theme).putInt("target", s.target).putLong("last", s.last).apply()
    }
}

object Updater {
    fun fraction(s: Settings, today: Long): Float {
        val start = if (s.startDay in 0..today) s.startDay else today
        val total = maxOf(1L, s.examDay - start)
        return (s.examDay - today).toFloat() / total
    }

    fun bitmapFor(s: Settings, theme: Int, w: Int, h: Int, today: Long): Bitmap {
        val date = LocalDate.ofEpochDay(s.examDay)
            .format(DateTimeFormatter.ofPattern("dd MMM yyyy", Locale.getDefault())).uppercase()
        return Renderer.render(w, h, Themes.all[theme.coerceIn(0, Themes.all.size - 1)], s.name,
            s.examDay - today, fraction(s, today), date)
    }

    fun apply(ctx: Context, force: Boolean): Boolean {
        val s = Prefs.load(ctx)
        if (s.examDay < 0) return false
        val today = LocalDate.now().toEpochDay()
        if (!force && s.last == today) return false
        val dm = ctx.resources.displayMetrics
        val bmp = bitmapFor(s, s.theme, dm.widthPixels, dm.heightPixels, today)
        val wm = WallpaperManager.getInstance(ctx)
        val flags = when (s.target) {
            0 -> WallpaperManager.FLAG_SYSTEM
            1 -> WallpaperManager.FLAG_LOCK
            else -> WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
        }
        wm.setBitmap(bmp, null, true, flags)
        bmp.recycle()
        s.last = today
        Prefs.save(ctx, s)
        return true
    }
}

class DailyWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        try { Updater.apply(applicationContext, false) } catch (e: Exception) { }
        Scheduler.scheduleMidnight(applicationContext)
        return Result.success()
    }
}

object Scheduler {
    fun schedule(ctx: Context) {
        val wm = WorkManager.getInstance(ctx)
        wm.enqueueUniquePeriodicWork("periodic", ExistingPeriodicWorkPolicy.KEEP,
            PeriodicWorkRequestBuilder<DailyWorker>(3, TimeUnit.HOURS).build())
        scheduleMidnight(ctx)
    }

    fun scheduleMidnight(ctx: Context) {
        val now = LocalDateTime.now()
        val next = now.toLocalDate().plusDays(1).atTime(0, 5)
        val delay = Duration.between(now, next).toMillis()
        WorkManager.getInstance(ctx).enqueueUniqueWork("midnight", ExistingWorkPolicy.APPEND_OR_REPLACE,
            OneTimeWorkRequestBuilder<DailyWorker>().setInitialDelay(delay, TimeUnit.MILLISECONDS).build())
    }
}
