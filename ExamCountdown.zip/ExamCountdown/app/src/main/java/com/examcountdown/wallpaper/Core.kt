package com.examcountdown.wallpaper

import android.app.WallpaperManager
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import android.os.Build
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.work.*
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.concurrent.TimeUnit

data class Settings(
    var name: String = "Final Exam", var examDay: Long = -1, var startDay: Long = -1,
    var theme: Int = 0, var target: Int = 2, var last: Long = -1, var quote: Boolean = true,
    var mode: Int = 0, var style: Int = 0, var dim: Int = 25, var blur: Int = 0, var pos: Int = 1,
    var acc: Int = 0, var ink: Int = 0, var fx: Int = 50, var fy: Int = 50,
    var startSet: Boolean = false
)

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("exam_prefs", Context.MODE_PRIVATE)
    fun load(c: Context): Settings {
        val p = sp(c)
        return Settings(p.getString("name", "Final Exam") ?: "Final Exam", p.getLong("exam", -1),
            p.getLong("start", -1), p.getInt("theme", 0), p.getInt("target", 2), p.getLong("last", -1),
            p.getBoolean("quote", true), p.getInt("mode", 0), p.getInt("style", 0), p.getInt("dim", 25),
            p.getInt("blur", 0), p.getInt("pos", 1), p.getInt("acc", 0), p.getInt("ink", 0),
            p.getInt("fx", 50), p.getInt("fy", 50), p.getBoolean("startSet", false))
    }
    fun save(c: Context, s: Settings) {
        sp(c).edit().putString("name", s.name).putLong("exam", s.examDay).putLong("start", s.startDay)
            .putInt("theme", s.theme).putInt("target", s.target).putLong("last", s.last)
            .putBoolean("quote", s.quote).putInt("mode", s.mode).putInt("style", s.style)
            .putInt("dim", s.dim).putInt("blur", s.blur).putInt("pos", s.pos).putInt("acc", s.acc)
            .putInt("ink", s.ink).putInt("fx", s.fx).putInt("fy", s.fy)
            .putBoolean("startSet", s.startSet).apply()
    }
}

/** Real physical screen size (including status and navigation bars), always portrait. */
object Screen {
    fun size(ctx: Context): Pair<Int, Int> {
        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        var a: Int
        var b: Int
        if (Build.VERSION.SDK_INT >= 30) {
            val bounds = wm.maximumWindowMetrics.bounds
            a = bounds.width(); b = bounds.height()
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(dm)
            a = dm.widthPixels; b = dm.heightPixels
        }
        return Pair(minOf(a, b), maxOf(a, b))
    }
}

object Updater {
    fun fraction(s: Settings, today: Long): Float {
        val start = if (s.startDay in 0..today) s.startDay else today
        val total = maxOf(1L, s.examDay - start)
        return (s.examDay - today).toFloat() / total
    }

    private fun dateText(s: Settings) = LocalDate.ofEpochDay(s.examDay)
        .format(DateTimeFormatter.ofPattern("dd MMM yyyy", Locale.getDefault())).uppercase()

    private fun theme(i: Int) = Themes.all[i.coerceIn(0, Themes.all.size - 1)]

    fun activeIndex(s: Settings) = if (s.mode == 1) s.style else s.theme

    private fun optsOf(s: Settings) = PhotoOpts(s.style, s.dim, s.blur, s.pos, s.acc, s.ink, s.fx, s.fy)

    /** index = theme index (gradient mode) or overlay style index (photo mode). */
    fun bitmapFor(ctx: Context, s: Settings, index: Int, w: Int, h: Int, today: Long, preview: Boolean): Bitmap {
        val q = if (s.quote) Quotes.forDay(today) else null
        if (s.mode == 1) {
            val photo = if (preview) PhotoStore.cached(ctx) else PhotoStore.load(ctx, w, h)
            val o = optsOf(s).copy(style = index)
            val out = PhotoRenderer.render(photo, w, h, o, s.name, s.examDay - today,
                fraction(s, today), dateText(s), q)
            if (!preview) photo?.recycle()
            return out
        }
        return Renderer.render(w, h, theme(index), s.name, s.examDay - today,
            fraction(s, today), dateText(s), q)
    }

    fun widgetBitmap(
        ctx: Context, s: Settings, index: Int, w: Int, h: Int, today: Long,
        allowQuote: Boolean, preview: Boolean
    ): Bitmap {
        val q = if (s.quote && allowQuote) Quotes.forDay(today) else null
        if (s.mode == 1) {
            val photo = if (preview) PhotoStore.cached(ctx) else PhotoStore.load(ctx, w, h)
            val pair = PhotoRenderer.widgetBackground(photo, optsOf(s), w, h)
            val out = Renderer.renderWidget(w, h, pair.second, s.name, s.examDay - today,
                fraction(s, today), dateText(s), q, pair.first)
            if (!preview) photo?.recycle()
            return out
        }
        return Renderer.renderWidget(w, h, theme(index), s.name, s.examDay - today,
            fraction(s, today), dateText(s), q, null)
    }

    fun refreshWidgets(ctx: Context) {
        try {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, CountdownWidget::class.java))
            for (id in ids) WidgetUpdater.update(ctx, mgr, id)
        } catch (e: Exception) { }
    }

    fun isLiveActive(ctx: Context): Boolean = try {
        WallpaperManager.getInstance(ctx).wallpaperInfo?.packageName == ctx.packageName
    } catch (e: Exception) { false }

    /** Returns true if the wallpaper was changed. Widgets are always refreshed. */
    fun apply(ctx: Context, force: Boolean): Boolean {
        val s = Prefs.load(ctx)
        if (s.examDay < 0) return false
        if (s.mode == 1 && !PhotoStore.exists(ctx)) return false
        val today = LocalDate.now().toEpochDay()
        refreshWidgets(ctx)
        // The adaptive live wallpaper redraws itself, so the daily job must not replace it.
        if (!force && isLiveActive(ctx)) return false
        if (!force && s.last == today) return false

        // Exact screen size: the launcher has nothing to scroll, so the wallpaper stays still.
        val size = Screen.size(ctx)
        val w = size.first
        val h = size.second
        val bmp = bitmapFor(ctx, s, activeIndex(s), w, h, today, false)
        val wm = WallpaperManager.getInstance(ctx)
        try { wm.suggestDesiredDimensions(w, h) } catch (e: Exception) { }
        val flags = when (s.target) {
            0 -> WallpaperManager.FLAG_SYSTEM
            1 -> WallpaperManager.FLAG_LOCK
            else -> WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
        }
        wm.setBitmap(bmp, Rect(0, 0, w, h), true, flags)
        bmp.recycle()
        s.last = today
        Prefs.save(ctx, s)
        return true
    }
}

class DailyWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        try { Updater.apply(applicationContext, false) } catch (e: Exception) { }
        Scheduler.scheduleMidnight(applicationContext)
        return Result.success()
    }
}

object Scheduler {
    fun schedule(ctx: Context) {
        val wm = WorkManager.getInstance(ctx)
        wm.enqueueUniquePeriodicWork("periodic", ExistingPeriodicWorkPolicy.KEEP,
            PeriodicWorkRequestBuilder<DailyWorker>(3, TimeUnit.HOURS).build())
        scheduleMidnight(ctx)
    }

    fun scheduleMidnight(ctx: Context) {
        val now = LocalDateTime.now()
        val next = now.toLocalDate().plusDays(1).atTime(0, 5)
        val delay = Duration.between(now, next).toMillis()
        WorkManager.getInstance(ctx).enqueueUniqueWork("midnight", ExistingWorkPolicy.APPEND_OR_REPLACE,
            OneTimeWorkRequestBuilder<DailyWorker>().setInitialDelay(delay, TimeUnit.MILLISECONDS).build())
    }
}
