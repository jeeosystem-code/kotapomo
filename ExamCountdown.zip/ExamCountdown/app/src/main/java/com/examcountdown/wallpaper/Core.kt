package com.examcountdown.wallpaper

import android.app.WallpaperManager
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import android.os.Build
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.work.*
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.concurrent.TimeUnit

data class Settings(
    var name: String = "Final Exam", var examDay: Long = -1, var startDay: Long = -1,
    var theme: Int = 0, var target: Int = 2, var last: Long = -1, var quote: Boolean = true
)

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("exam_prefs", Context.MODE_PRIVATE)
    fun load(c: Context): Settings {
        val p = sp(c)
        return Settings(p.getString("name", "Final Exam") ?: "Final Exam", p.getLong("exam", -1),
            p.getLong("start", -1), p.getInt("theme", 0), p.getInt("target", 2), p.getLong("last", -1),
            p.getBoolean("quote", true))
    }
    fun save(c: Context, s: Settings) {
        sp(c).edit().putString("name", s.name).putLong("exam", s.examDay).putLong("start", s.startDay)
            .putInt("theme", s.theme).putInt("target", s.target).putLong("last", s.last)
            .putBoolean("quote", s.quote).apply()
    }
}

/** Real physical screen size (including status and navigation bars), always portrait. */
object Screen {
    fun size(ctx: Context): Pair<Int, Int> {
        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        var a: Int
        var b: Int
        if (Build.VERSION.SDK_INT >= 30) {
            val bounds = wm.maximumWindowMetrics.bounds
            a = bounds.width(); b = bounds.height()
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(dm)
            a = dm.widthPixels; b = dm.heightPixels
        }
        return Pair(minOf(a, b), maxOf(a, b))
    }
}

object Updater {
    fun fraction(s: Settings, today: Long): Float {
        val start = if (s.startDay in 0..today) s.startDay else today
        val total = maxOf(1L, s.examDay - start)
        return (s.examDay - today).toFloat() / total
    }

    private fun dateText(s: Settings) = LocalDate.ofEpochDay(s.examDay)
        .format(DateTimeFormatter.ofPattern("dd MMM yyyy", Locale.getDefault())).uppercase()

    private fun theme(i: Int) = Themes.all[i.coerceIn(0, Themes.all.size - 1)]

    fun bitmapFor(s: Settings, theme: Int, w: Int, h: Int, today: Long): Bitmap {
        val q = if (s.quote) Quotes.forDay(today) else null
        return Renderer.render(w, h, theme(theme), s.name, s.examDay - today,
            fraction(s, today), dateText(s), q)
    }

    fun widgetBitmap(s: Settings, theme: Int, w: Int, h: Int, today: Long, allowQuote: Boolean): Bitmap {
        val q = if (s.quote && allowQuote) Quotes.forDay(today) else null
        return Renderer.renderWidget(w, h, theme(theme), s.name, s.examDay - today,
            fraction(s, today), dateText(s), q)
    }

    fun refreshWidgets(ctx: Context) {
        try {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, CountdownWidget::class.java))
            for (id in ids) WidgetUpdater.update(ctx, mgr, id)
        } catch (e: Exception) { }
    }

    /** Returns true if the wallpaper was changed. Widgets are always refreshed. */
    fun apply(ctx: Context, force: Boolean): Boolean {
        val s = Prefs.load(ctx)
        if (s.examDay < 0) return false
        val today = LocalDate.now().toEpochDay()
        refreshWidgets(ctx)
        if (!force && s.last == today) return false

        // Exact screen size: the launcher has nothing to scroll, so the wallpaper stays still.
        val size = Screen.size(ctx)
        val w = size.first
        val h = size.second
        val bmp = bitmapFor(s, s.theme, w, h, today)
        val wm = WallpaperManager.getInstance(ctx)
        try { wm.suggestDesiredDimensions(w, h) } catch (e: Exception) { }
        val flags = when (s.target) {
            0 -> WallpaperManager.FLAG_SYSTEM
            1 -> WallpaperManager.FLAG_LOCK
            else -> WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
        }
        wm.setBitmap(bmp, Rect(0, 0, w, h), true, flags)
        bmp.recycle()
        s.last = today
        Prefs.save(ctx, s)
        return true
    }
}

class DailyWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        try { Updater.apply(applicationContext, false) } catch (e: Exception) { }
        Scheduler.scheduleMidnight(applicationContext)
        return Result.success()
    }
}

object Scheduler {
    fun schedule(ctx: Context) {
        val wm = WorkManager.getInstance(ctx)
        wm.enqueueUniquePeriodicWork("periodic", ExistingPeriodicWorkPolicy.KEEP,
            PeriodicWorkRequestBuilder<DailyWorker>(3, TimeUnit.HOURS).build())
        scheduleMidnight(ctx)
    }

    fun scheduleMidnight(ctx: Context) {
        val now = LocalDateTime.now()
        val next = now.toLocalDate().plusDays(1).atTime(0, 5)
        val delay = Duration.between(now, next).toMillis()
        WorkManager.getInstance(ctx).enqueueUniqueWork("midnight", ExistingWorkPolicy.APPEND_OR_REPLACE,
            OneTimeWorkRequestBuilder<DailyWorker>().setInitialDelay(delay, TimeUnit.MILLISECONDS).build())
    }
}
