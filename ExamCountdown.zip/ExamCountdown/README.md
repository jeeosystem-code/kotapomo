# Exam Countdown
Daily-updating exam countdown wallpaper. 5 themes. Only permission: SET_WALLPAPER.
Build: push to GitHub -> Actions -> "Build APK" -> download artifact.
